﻿using System.Collections.Generic;
using System.Linq;

namespace Day34MVCAuth.Models
{
    public class StudentList
    {
        public List<Student> Students;

        public StudentList()
        {
            Students = new List<Student>
            {
                new Student { Id = 1, Name = "John Doe", Age = 20, Course = "Computer Science" },
                new Student { Id = 2, Name = "Jane Smith", Age = 22, Course = "Mathematics" },
                new Student { Id = 3, Name = "Alice Johnson", Age = 21, Course = "History" },
                new Student { Id = 4, Name = "Bob Williams", Age = 23, Course = "Physics" },
                new Student { Id = 5, Name = "Eve Davis", Age = 20, Course = "Chemistry" },
                new Student { Id = 6, Name = "Charlie Brown", Age = 22, Course = "Biology" },
                new Student { Id = 7, Name = "Grace Lee", Age = 24, Course = "Engineering" },
                new Student { Id = 8, Name = "David Miller", Age = 21, Course = "Psychology" },
                new Student { Id = 9, Name = "Sophia Hall", Age = 19, Course = "English" },
                new Student { Id = 10, Name = "Oliver Clark", Age = 25, Course = "Sociology" }
            };

        }

        public void AddStudent(int id,string name, int age,string course)
        {
            
            Students.Add(new Student { Id = id, Name = name, Age = age, Course = course });
        }
    }
}
