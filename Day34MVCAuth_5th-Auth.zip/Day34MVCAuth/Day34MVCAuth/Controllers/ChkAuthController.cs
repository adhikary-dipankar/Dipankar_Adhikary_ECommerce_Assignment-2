﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Day34MVCAuth.Controllers
{
    public class ChkAuthController : Controller
    {
        // GET: CheckAuth
        public ContentResult Index()
        {
            return Content("Hello, You are Guest.");
        }

        // GET: CheckAuth/AuthorisedOnly  
        [Authorize]
        public ContentResult AuthorisedOnly()
        {
            return Content("You are registered user.");
        }
        [Authorize]
        public IActionResult Welcome()
        {
            return View();
        }
    }
}
