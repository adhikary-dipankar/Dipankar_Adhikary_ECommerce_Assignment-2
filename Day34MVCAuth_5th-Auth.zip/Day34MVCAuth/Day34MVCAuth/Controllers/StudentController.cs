﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Day34MVCAuth.Models;

namespace Day34MVCAuth.Controllers
{
    public class StudentController : Controller
    {
        private readonly StudentList studentList;

        public StudentController()
        {
            studentList = new StudentList();
        }

        
        [AllowAnonymous]
        public IActionResult Index()
        {
            return View(studentList.Students);
        }

        
        [Authorize]
        public IActionResult AddStudent()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        public IActionResult AddStudent(int id, string name, int age, string course)
        {
            studentList.AddStudent(id, name, age, course);
            return RedirectToAction("Index");
        }
    }
}
