﻿using Microsoft.AspNetCore.Mvc;

namespace Day34MVC.Controllers
{
    public class ActFilterController : Controller
    {
        [ResponseCache(Duration = 10)]   
        public IActionResult Index()
        {
            return View();
        }
    }
}
