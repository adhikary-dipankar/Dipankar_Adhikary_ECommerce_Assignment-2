﻿using EmployeeMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace EmployeeMVC.Controllers
{
    public class EmployeeController : Controller
    {
        static Employees emp= new Employees();
        public IActionResult Index()
        {
            return View(emp.returnList());
        }

        public JsonResult Show()
        {
            return Json(emp.returnList());
        }

        public IActionResult AddEmp(int id,string name)
        {
            emp.AddEmp(id,name);
            return View();
        }
    }
}
