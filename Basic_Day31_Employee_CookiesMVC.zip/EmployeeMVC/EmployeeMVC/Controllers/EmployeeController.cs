﻿using EmployeeMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace EmployeeMVC.Controllers
{
    public class EmployeeController : Controller
    {
        static Employees emp= new Employees();
        static List<Employee> EmpL= new List<Employee>();
      
        public IActionResult Index()
        {
            return View();
        }

        public JsonResult Show()
        {
            return Json(emp.returnList());
        }

        public IActionResult AddEmp(int id,string name,int age)
        {
            emp.AddEmp(id,name,age);
            return View();
        }

        public IActionResult ShowList()
        {
            return View(emp.returnList());
        }

        public IActionResult SearchId(int id) 
        {
            Employee e = emp.SearchById(id);
            ViewData["Emp"] = e;
            return View();
        }

        public IActionResult SearchName(string name)
        {
            Employee e = emp.SearchByName(name);
            ViewData["Emp1"] = e;
            return View();
        }
        public IActionResult SearchAge(int age )
        {
            Employee e = emp.SearchByAge(age);
            ViewData["Emp2"] = e;
            return View();
        }

        public IActionResult SearchAgeRange(int minAge,int maxAge)
        {
            ViewData["Emp3"] = emp.SearchByAgeRange(minAge, maxAge);

            return View();
        }
    }
}
