﻿using System.Collections.Generic;

namespace EmployeeMVC.Models
{
    public class Employees
    {
        public List<Employee> EmpList;

        public Employees()
        {
            EmpList = new List<Employee>();
            EmpList.Add(new Employee(101, "Dipankar", 23));
            EmpList.Add(new Employee(102, "Linux", 10));
            EmpList.Add(new Employee(103, "Windows", 28));
            EmpList.Add(new Employee(104, "Macintosh", 16));
            EmpList.Add(new Employee(105, "Kali", 32));

        }
        public List<Employee> returnList()
        {

            return EmpList;

        }
        public void AddEmp(int id, string name, int age)
        {
            EmpList.Add(new Employee(id, name, age));
        }

        public Employee SearchById(int id)
        {
            foreach (Employee e in EmpList)
            {
                if (e.Id == id)
                {
                    return e;
                }
            }
            return null;

        }

        public Employee SearchByName(string name)
        {
            foreach (Employee e in EmpList)
            {
                if (e.Name == name)
                {
                    return e;
                }
            }
            return null;

        }
        public Employee SearchByAge(int age)
        {
            foreach (Employee e in EmpList)
            {
                if (e.Age == age)
                {
                    return e;
                }
            }
            return null;

        }

        public List<Employee> SearchByAgeRange(int minAge,int maxAge)
        {
            List<Employee> EMPList = new List<Employee>();
            foreach(Employee e in EmpList)
            {
                if (e.Age<=maxAge && e.Age>=minAge)
                {
                    EMPList.Add(e);
                }
            }
            return EMPList;
        }
    }
}
