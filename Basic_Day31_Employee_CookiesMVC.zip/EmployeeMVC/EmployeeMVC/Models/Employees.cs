﻿using System.Collections.Generic;

namespace EmployeeMVC.Models
{
    public class Employees
    {
        public List<Employee> EmpList;

        public Employees()
        {
            EmpList = new List<Employee>();
            EmpList.Add(new Employee(101,"Dipankar"));
            EmpList.Add(new Employee(102, "Linux"));
            EmpList.Add(new Employee(103, "Windows"));
            EmpList.Add(new Employee(104, "Macintosh"));
            EmpList.Add(new Employee(105, "Kali"));

        }
        public List<Employee> returnList() { 
        
            return EmpList;
            
        }
        public void AddEmp(int id, string name)
        {
            EmpList.Add(new Employee(id, name));
        }
    }
}
