﻿using System.Collections.Generic;

namespace EmployeeMVC.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Employee(int id, string name)
        {
            this.Id = id;
            this.Name = name;
        }
        public override string ToString()
        {
            return "Employee Name : "+Name+"  Employee Id : "+Id;
        }
        public Employee() { }

    }
}



