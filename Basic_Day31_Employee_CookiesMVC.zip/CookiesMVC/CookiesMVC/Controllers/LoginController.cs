﻿using Microsoft.AspNetCore.Mvc;

namespace CookiesMVC.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult LoginPage(string Username, string Password)
        {
            if (Username != null)
            {
                HttpContext.Response.Cookies.Append("Username", Username);
            }

            if (Password != null)
            {
                HttpContext.Response.Cookies.Append("Password", Password);
            }
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Logout()
        {
            
            return View();
        }

        public IActionResult Inbox()
        {
            
            return View();
        }

        public IActionResult Draft()
        {
            
            return View();
        }

        public IActionResult Sent()
        {
          
            return View();
        }

        public IActionResult Compose()
        {
           
            return View();
        }
    }

}
