﻿using System.Collections.Generic;
using System.Net.NetworkInformation;

namespace BasicMVC.Models
{

        public string Validate(int age)
        {
            if (age < 0 || age > 150)
            {
                return "Ghost Employee";
            }
            else if (age > 60)
            {
                return "Senior Citizen Employee";
            }
            else if (age < 20)
            {
                return "Child Employee";
            }
            else
            {
                return "Good Working Employee";
            }

        }
    }
}
