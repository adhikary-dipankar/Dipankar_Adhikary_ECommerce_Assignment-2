﻿using BasicMVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace BasicMVC.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {

            return View();
        }

        public IActionResult EmployeeForm()
        {

            return View();
        }

        public IActionResult Hr(string name,int age)
        {
            Employee e = new Employee();
            ViewData["Name"] = name;
            ViewData["Age"] = age;

            string m = e.Validate(age);
            ViewData["ageMsg"] = m;
            return View();
        }
    }
}
