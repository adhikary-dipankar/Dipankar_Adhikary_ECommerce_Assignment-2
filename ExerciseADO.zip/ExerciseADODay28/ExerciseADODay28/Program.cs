﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciseADODay28
{
    internal class Program
    {
        static void Main(string[] args)
        {


            try
            {
                Console.WriteLine("Enter your Username: ");
                string username = Console.ReadLine();

                Console.WriteLine("Enter your Password: ");
                string password = Console.ReadLine();

                string connectionString = @"Data Source=DESKTOP-O7LF2JA;Initial Catalog=training;Integrated Security=True";



                SqlConnection connection = new SqlConnection(connectionString);

                connection.Open();

                string query = "Select count(*) from Login where uname=@username and passwd=@password";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("username", username);
                command.Parameters.AddWithValue("password", password);

                int ch = (int)command.ExecuteNonQuery();
                if (ch > 0)
                {
                    Console.WriteLine("Login Successful.");

                }
                else
                {
                    Console.WriteLine("Login Not Successful.");
                }

            }
            catch (Exception ex) { Console.WriteLine(ex.ToString()); }
            Console.ReadLine();
        }
    }

}
