﻿using Microsoft.AspNetCore.Mvc;

namespace Day27MySite.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
