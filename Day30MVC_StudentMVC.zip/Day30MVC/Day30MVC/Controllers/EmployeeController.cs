﻿using Day30MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace Day30MVC.Controllers
{
    public class EmployeeController : Controller
    {
        static EmployeeList emps = new EmployeeList();
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult WelcomeEmp(string name)
        {
            TempData["Emp"] = emps.getEmp(name);
            return View();
        }
        public IActionResult WelcomeEmp2(string name)
        {
            TempData["EmpName"] = name;
            return View();
        }
        public IActionResult ListEmp()
        {
            return View(emps.emps);
        }

        public JsonResult ListEmp2()
        {
            return Json(emps.emps);
        }

        public IActionResult AddEmpPage()
        {
            return View();
        }

        public IActionResult AddEmpToList(string name,int id)
        {

            emps.AddEmp(new Employee(name, id));

            return RedirectToAction("ListEmp");
        }

        public IActionResult UpdateEmpList()
        {
           
            return View();
        }

        public IActionResult UpdateEmp(int id,string NewName)
        {
            emps.UpdateEmployeeName(id,NewName);
            return RedirectToAction("ListEmp");
        }

    }
}
