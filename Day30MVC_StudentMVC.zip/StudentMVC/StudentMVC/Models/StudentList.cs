﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;

namespace StudentMVC.Models
{
    public class StudentList
    {
        public List<Student> stds = new List<Student>();
        public StudentList(List<Student> stds) { this.stds = stds; }
        public StudentList(Student std) { this.stds.Add(std); }
        public StudentList()
        {
            this.AddStd(new Student("Dipankar", 101, "B.Tech", 4, 2019, 1000000));
            this.AddStd(new Student("John", 102, "M.Sc", 2, 2020, 800000));
            this.AddStd(new Student("Alice", 103, "B.A", 3, 2018, 600000));
            this.AddStd(new Student("Bob", 104, "Ph.D", 5, 2017, 1200000));
            this.AddStd(new Student("Luke", 105, "M.Sc", 2, 2020, 800000));
            this.AddStd(new Student("Emily", 106, "Ph.D", 5, 2018, 1200000));
            this.AddStd(new Student("David", 107, "B.A", 3, 2021, 600000));

        }
        public void AddStd(Student std) { this.stds.Add(std); }

        public void UpdateStd(int id,Student upstd)
        {
            Student s = this.stds.Find(std => std.Id == id);
            if (s != null)
            {
                
                s.Name = upstd.Name;
                s.Course = upstd.Course;
                s.Duration = upstd.Duration;
                s.YearOfEnrollment = upstd.YearOfEnrollment;
                s.Fees = upstd.Fees;
            }
            else
            {
                Console.WriteLine("Student Not Found !!");
            }
        }



        public void DelStd(int id)
        {
            stds.RemoveAll(std => std.Id == id);
        }

  
        public List<Student> GetAllStds()
        {
            return stds;
        }

    


        public Student GetStudentById(int Id)
        {
            Student s = new Student("Default", 000, "No Course", 0, 0000, 000000);
            foreach (Student ss in stds)
            {
                if (ss.Id.Equals(Id))
                {
                    s = ss;
                }
            }
            return s;
        }



    }
}
