﻿using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace StudentMVC.Models
{

    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
        public int Duration { get; set; }
        public int YearOfEnrollment { get; set; }
        public int Fees { get; set; }


        public Student(string name, int id, string course, int duration, int yearofenr, int fee)
        {
            this.Name = name;
            this.Id = id;
            this.Course = course;
            this.Duration = duration;
            this.YearOfEnrollment = yearofenr;
            this.Fees = fee;

        }

        public Student() { }

        public override string ToString()
        {
            return "\nStudent Overiride Name : " + Name +
                "\nId : " + Id +
                "\nCourse Name : " + Course +
                "\nDuration : " + Duration +
                "\nYear of Enrollment : " + YearOfEnrollment +
                "\nFees : " + Fees;
        }
    }



}
