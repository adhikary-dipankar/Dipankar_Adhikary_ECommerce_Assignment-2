﻿using Microsoft.AspNetCore.Mvc;
using StudentMVC.Models;
using System.Collections.Generic;
using System.Xml.Linq;

namespace StudentMVC.Controllers
{
    public class StudentController : Controller
    {
        static StudentList stds = new StudentList();

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult AddStdPage()
        {
            return View();
        }

        public IActionResult AddStd(string Name, int Id, string Course, int Duration, int YearOfEnrollment, int Fees)
        {
            stds.AddStd(new Student(Name, Id,Course,Duration,YearOfEnrollment,Fees));
            return RedirectToAction("DisplayStdPage");
        }

        public IActionResult UpdateStdPage()
        {
            return View();
        }

        public IActionResult UpdateStd(string Name, int Id, string Course, int Duration, int YearOfEnrollment, int Fees)
        {
            stds.UpdateStd(Id,(new Student(Name, Id, Course, Duration, YearOfEnrollment, Fees)));
            return RedirectToAction("DisplayStdPage");
        }


        public IActionResult DeleteStdPage()
        {
            return View();
        }

        public IActionResult DeleteStd(int Id)
        {
            stds.DelStd(Id);

            return RedirectToAction("DisplayStdPage");
        }


        public IActionResult DisplayStdPage()
        {
            List<Student> students = stds.GetAllStds();
            return View(students);

   
        }

        public IActionResult SearchByIdPage()
        {
            return View();
        }
       
        public IActionResult SearchById(int Id)
        {
            TempData["Student"]=stds.GetStudentById(Id);
            
            return View();

           
        }


        public IActionResult SearchByCriteriaPage()
        {
            return View();
        }


        public IActionResult SearchByCriteria(string course, string name, int duration, int year, decimal minFees, decimal maxFees)
        {
            return View();
        }
    }
}
