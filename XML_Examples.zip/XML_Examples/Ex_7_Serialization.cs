using System;
using System.IO;
using System.Xml.Serialization;

// Define a Student class to represent the data
[Serializable]
public class Student
{
    public string Name { get; set; }
    public int Age { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        // Create a new student
        Student student = new Student{Name = "Bumrah",Age = 28};

        // Serialize the student object to XML

        XmlSerializer serializer = new XmlSerializer(typeof(Student));
        using (TextWriter writer = new StreamWriter("student.xml"))
        {
            serializer.Serialize(writer, student);
        }

        Console.WriteLine("Student object serialized to student.xml");

        // Deserialize the XML back to a student object

        using (TextReader reader = new StreamReader("student.xml"))
        {
            var deserializedStudent = (Student)serializer.Deserialize(reader);
            Console.WriteLine($"Deserialized Student - Student Name: {deserializedStudent.Name}, Age: {deserializedStudent.Age}");
        }
    }
}
