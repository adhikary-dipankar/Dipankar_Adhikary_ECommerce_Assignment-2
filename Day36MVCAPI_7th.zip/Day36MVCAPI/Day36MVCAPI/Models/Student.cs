﻿namespace Day36MVCAPI.Models
{
    public class Student
    {
        public string studentID { get; set; }
        public string surName { get; set; }   
    }
}
