﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Day36MVCAPI.Models
{
    public class StudentContext
    {
        public List<Student> Students = new List<Student>();

    }
}
