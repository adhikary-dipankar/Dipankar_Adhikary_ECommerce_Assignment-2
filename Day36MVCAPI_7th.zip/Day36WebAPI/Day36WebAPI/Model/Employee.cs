﻿namespace Day36WebAPI.Model
{
    public class Employee
    {
        public int Eid { get; set; }
        public string Ename { get; set; }
        public decimal Esal { get; set; }
        public string Eaddress { get; set; }
        public string Ephone { get; set; }

        public Employee(int eid, string ename, decimal esal, string eaddress, string ephone)
        {
            Eid = eid;
            Ename = ename;
            Esal = esal;
            Eaddress = eaddress;
            Ephone = ephone;
        }
        public Employee() { }

        //public override string ToString()
        //{
        //    return "E-Id: " + Eid + "  E-Name: " + Ename + "  E-Salary: " +Esal+"  E-Address: "+Eaddress+"  E-Phone: "+Ephone;
        //}

    }
    
}
