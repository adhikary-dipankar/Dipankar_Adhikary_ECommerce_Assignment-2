﻿using System.Collections.Generic;
using System.Linq;

namespace Day36WebAPI.Model
{
    public class EmpList
    {
        public static List<Employee> employees = new List<Employee>
        {
            new Employee { Eid = 1, Ename = "Virat", Esal = 150000, Eaddress = "Delhi", Ephone = "985551234" },
            new Employee { Eid = 2, Ename = "Ms Dhoni", Esal = 160000, Eaddress = "Chennai", Ephone = "985555678" },
            new Employee { Eid = 3, Ename = "Rohit", Esal = 155000, Eaddress = "Pune", Ephone = "985559876" },
            new Employee { Eid = 4, Ename = "KL Rahul", Esal = 162000, Eaddress = "Delhi", Ephone = "985554321" },
            new Employee { Eid = 5, Ename = "Siraj", Esal = 153000, Eaddress = "Mumbai", Ephone = "985558765" },
            new Employee { Eid = 6, Ename = "Dipankar", Esal = 553000, Eaddress = "Kolkata", Ephone = "985558765" }
        };

        public List<Employee> GetEmps()
        {
            return employees;
        }

        public Employee GetEmp(int eid)
        {
            return employees.FirstOrDefault(e => e.Eid == eid);
        }

        public void AddEmp(int eid, string ename, decimal esal, string eaddress, string ephone)
        {
            employees.Add(new Employee { Eid = eid, Ename = ename, Esal = esal, Eaddress = eaddress, Ephone = ephone }); 
            
        }

        public void DelEmp(int eid)
        {
            var employee = employees.FirstOrDefault(e => e.Eid == eid);
            if (employee != null)
            {
                employees.Remove(employee);
               
            }
        }
    }
}
