﻿using Day36WebAPI.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Day36WebAPI.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        static Employee employee = new Employee();
        private readonly EmpList empList = new EmpList();

        [HttpGet("GetEmps")]
        public ActionResult<IEnumerable<Employee>> GetEmps()
        {

            return empList.GetEmps();
        }

        [HttpGet("GetEmp/{eid}")]
        public ActionResult<Employee> GetEmp(int eid)
        {
            var employee = empList.GetEmp(eid);
            if (employee == null)
            {
                return NotFound();
            }
            return employee;
        }
 
        [HttpPost("AddEmp")]
        public IActionResult AddEmp(int eid, string ename, decimal esal, string eaddress, string ephone)
        {
            empList.AddEmp(eid,ename,esal,eaddress,ephone);
            return CreatedAtAction(nameof(GetEmp), new { eid = employee.Eid }, employee);
        }

        [HttpDelete("DelEmp/{eid}")]
        public IActionResult DelEmp(int eid)
        {
            empList.DelEmp(eid);
            return NoContent();
        }
    }
}
