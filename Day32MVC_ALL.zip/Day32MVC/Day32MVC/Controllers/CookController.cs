﻿using Microsoft.AspNetCore.Mvc;

namespace Day32MVC.Controllers
{
    public class CookController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddCooky(string cooky)
        {
            HttpContext.Response.Cookies.Append("cc", cooky);

            return View();
        }

        public IActionResult ViewCooky(string cooky) 
        {
            string myCooky = "";
            if (HttpContext.Request.Cookies.ContainsKey("cc"))
            {
                myCooky = HttpContext.Request.Cookies["cc"];
            }
            ViewData["C"] = myCooky;
            return View();
        }

    }
}
