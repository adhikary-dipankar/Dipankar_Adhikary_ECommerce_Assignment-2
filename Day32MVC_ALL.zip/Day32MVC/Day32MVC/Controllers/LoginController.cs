﻿using Microsoft.AspNetCore.Mvc;

namespace Day32MVC.Controllers
{
    public class LoginController : Controller
    {
        public string u;
        public string p;

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult LoginPage()
        {
            return View();
        }

        public IActionResult Loggin(string uname, string pass)
        {

            HttpContext.Response.Cookies.Append("U", uname);
            HttpContext.Response.Cookies.Append("P", pass);

            //if (uname != null && pass != null)
            //{
            //    HttpContext.Response.Cookies.Append("U", uname);
            //    HttpContext.Response.Cookies.Append("P", pass);
            //}
            //else
            //{
            //    return RedirectToAction("Index");
            //}

            return View();
        }

        public IActionResult Inbox(string uname, string pass)
        {
            u = HttpContext.Request.Cookies["U"];
            p = HttpContext.Request.Cookies["P"];
            if ((u!=null && p!=null)|| (u!="" && p!=""))
            {
                ViewData["User"] = u;
                ViewData["Pass"] = p;
                return View();
            }
            else
            {
                return RedirectToAction("LogErr");
            }
         
        }

        public IActionResult Draft()
        {
            u = HttpContext.Request.Cookies["U"];
            p = HttpContext.Request.Cookies["P"];
            if ((u != null && p != null) || (u != "" && p != ""))
            {
                ViewData["User"] = u;
                ViewData["Pass"] = p;
                return View();
            }
            else
            {
                return RedirectToAction("LogErr");
            }
        }

        public IActionResult Sent()
        {
            u = HttpContext.Request.Cookies["U"];
            p = HttpContext.Request.Cookies["P"];
            if ((u != null && p != null) || (u != "" && p != ""))
            {
                ViewData["User"] = u;
                ViewData["Pass"] = p;
                return View();
            }
            else
            {
                return RedirectToAction("LogErr");
            }
        }
        public IActionResult LogErr()
        {
            return View();
        }

        public IActionResult Logout(string uname, string pass)
        {
            if (uname != null && pass != null)
            {
                HttpContext.Response.Cookies.Append("U", "");
                HttpContext.Response.Cookies.Append("P", "");
            }
            return View();
        }
    }
}
