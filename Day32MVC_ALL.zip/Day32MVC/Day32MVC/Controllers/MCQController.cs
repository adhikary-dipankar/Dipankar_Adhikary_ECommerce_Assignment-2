﻿using Microsoft.AspNetCore.Mvc;

namespace Day32MVC.Controllers
{
    public class MCQController : Controller
    {
        public IActionResult Index()
        {
            HttpContext.Response.Cookies.Append("Q1", "0");
            HttpContext.Response.Cookies.Append("Q2", "0");
            HttpContext.Response.Cookies.Append("Q3", "0");


            return View();
        }
        static int i = 0;
        public IActionResult MCQ1(string ans)
        {
            if (HttpContext.Request.Cookies["Q2"] == "0" && ans == "No")
            {
                HttpContext.Response.Cookies.Append("Q2", "10");
                i = 0;
                if (i==0)
                {
                    i = 1;
                    return RedirectToAction("MCQ1");
                 
                }
            }
            return View();
        }

        public IActionResult MCQ2(string ans)
        {
            if (HttpContext.Request.Cookies["Q1"] == "0" && ans == "Cool")
            {
                i = 0;
                HttpContext.Response.Cookies.Append("Q1", "10");
                if (i == 0)
                {
                    i = 1;
                    return RedirectToAction("MCQ2");
                }
            }

            if (HttpContext.Request.Cookies["Q3"] == "0" && ans == "Yes")
            {
                i = 0;
                HttpContext.Response.Cookies.Append("Q3", "10");
                if (i == 0)
                {
                    i = 1;
                    return RedirectToAction("MCQ2");
                }
            }

            return View();
        }

        public IActionResult MCQ3(string ans)
        {
            if (HttpContext.Request.Cookies["Q2"] == "0" && ans == "No")
            {
                i = 0;
                HttpContext.Response.Cookies.Append("Q2", "10");
                if (i==0)
                {
                    i = 1;
                    return RedirectToAction("MCQ3");
                    
                }
            }
            return View();
        }

        public IActionResult Result()
        {
           

            int result = 0;
            if (int.TryParse(HttpContext.Request.Cookies["Q1"], out int q1Value))
            {
                result += q1Value;
            }
            if (int.TryParse(HttpContext.Request.Cookies["Q2"], out int q2Value))
            {
                result += q2Value;
            }
            if (int.TryParse(HttpContext.Request.Cookies["Q3"], out int q3Value))
            {
                result += q3Value;
            }
          
            ViewData["res"] = result;

            return View();
        }
    }
}
