﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;

namespace Day35MVC.Models
{
    public class MyExceptFilter
    : IExceptionFilter
    {
        private readonly IHostEnvironment _hostEnvironment;
        public MyExceptFilter(IHostEnvironment hostEnvironment) =>
            _hostEnvironment = hostEnvironment;
        public void OnException(ExceptionContext context)
        {
            if (!_hostEnvironment.IsDevelopment())
            {
                // Don't display exception details unless running in Development.
                return;
            }
            context.Result = new ContentResult
            {
                Content = context.Exception.ToString()
            };
        }
    }
}