﻿using Day35MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace Day35MVC.Controllers
{
    public class ExceptHandlerController : Controller
    {
        [TypeFilter(typeof(MyExceptFilter))]
        //public IActionResult Index()
        //{
        //    return View();
        //}
        public IActionResult Index() =>
     Content($"- {nameof(ExceptHandlerController)}.{nameof(Index)}");

    }
}

