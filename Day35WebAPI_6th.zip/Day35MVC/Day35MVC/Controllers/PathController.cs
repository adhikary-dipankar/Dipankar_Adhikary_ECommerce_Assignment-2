﻿using Microsoft.AspNetCore.Mvc;

namespace Day35MVC.Controllers
{
    [Route("[Controller]")]
    public class PathController : Controller
    {
       
        public IActionResult Index()
        {
            return View();
        }

        [Route("[Action]/{Id:int}")]
        public string GetHello(int id)
        {
            return "Hello "+id;
        }

        [Route("[Action]/{name}")]
        public string GetHello(string name)
        {
            if (name.Equals("ABC"))
                name = "USER";
            else
                name = "GUEST";
            return
                "Welcome to the Page : " + name;
        }

        [Route("[Action]/emp/DA")]
        public string GetHello()
        {
            return "Hello Dipankar Adhikary";
        }
    }
}
