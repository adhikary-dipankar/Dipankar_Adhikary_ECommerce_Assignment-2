﻿using Day35MVC.Models;
using Microsoft.AspNetCore.Mvc;

namespace Day35MVC.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult HTMLHelper1()
        {
            return View();
        }
        public IActionResult HTMLHelper2()
        {
            return View();
        }

        [HttpPost]
        public IActionResult HTMLHelper2(EmployeeClass emp)
        {
            return RedirectToAction("HTMLHelper3",emp);
        }


        public IActionResult HTMLHelper3(EmployeeClass emp)
        {
            return View(emp);
        }
    }
}
