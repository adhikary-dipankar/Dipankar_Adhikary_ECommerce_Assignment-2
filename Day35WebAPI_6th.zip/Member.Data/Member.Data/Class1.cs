﻿using System;

namespace Member.Data
{
    public class Class1
    {
    }
}
