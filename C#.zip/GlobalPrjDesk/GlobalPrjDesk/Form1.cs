﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GlobalPrjDesk
{
    public partial class Form1 : Form
    {

        public void myDesigner(string s)
        {
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(s);
            this.Controls.Clear();
            InitializeComponent();
            ResourceManager rm = new ResourceManager("GlobalPrjDesk.Form1", typeof(Form1).Assembly);
            string mess = rm.GetString("MyLanguage");
            MessageBox.Show(mess);

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            myDesigner("hi-IN");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            myDesigner("en-US");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            myDesigner("bn-IN");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            myDesigner("ta-IN");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show(Thread.CurrentThread.CurrentUICulture.Name);
            myDesigner(Thread.CurrentThread.CurrentUICulture.Name);
        }
    }
}
