﻿

//using System;

//namespace Prj1Day1Con
//{
//    public delegate string delMsg(string m);
//    class Messenger
//    {
//        public string username;
//        public event delMsg evntMsg;
//        public string grpMsg(string m)
//        {
//            return username + " : " + m;
//        }
//        public string one2oneMsg(string m)
//        {
//            return m;
//        }
//        public string consumer(string m)
//        {
//            return evntMsg(m);
//        }

//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Messenger m = new Messenger();
//            m.username = "Guest";
//            m.evntMsg += new delMsg(m.grpMsg);
//            m.evntMsg += new delMsg(m.one2oneMsg);
//            string s = m.consumer("This is a group message");
//            string s1 = m.consumer("This is a personal message");
//            Console.WriteLine(s);
//            Console.WriteLine(s1);
//        }

//    }
//}






//using System;

//namespace Prj1Day1Con
//{
//    public delegate int cal(int a, int b);


//    class Publisher
//    {
//        public event cal calEvnt;
//        public int add(int a, int b) { Console.WriteLine("In sum"); return a + b; }
//        public static int mul(int a, int b) { return a * b; }
//        public int sub(int a, int b) { return a > b ? a - b : b - a; }
//        public static int div(int a, int b) { return b == 0 ? 0 : a / b; }
//        public void consumer()
//        {
//            Console.WriteLine("Enter the first num:");
//            int x = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter the second num:");
//            int y = Convert.ToInt32(Console.ReadLine());
//            int res = calEvnt(x, y);
//            Console.WriteLine("Result is: " + res);
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            int ch = 0;
//            Publisher p = new Publisher();
//            //p.calEvnt += new cal(p.add);
//            //cfn(8, 9);
//            //while (true)
//            //{
//            Console.WriteLine("Menu: \n1. Add\n2. Sub\n3. Mul\n4. Div\n5. Exit\nEnter Choice:");
//            ch = Convert.ToInt32(Console.ReadLine());
//            if (ch == 1)
//            {
//                p.calEvnt += new cal(p.add);
//                p.consumer();
//            }
//            else if (ch == 2)
//            {
//                p.calEvnt += new cal(p.sub);
//                p.consumer();
//            }
//            else if (ch == 3)
//            {
//                p.calEvnt += new cal(Publisher.mul);
//                p.consumer();
//            }
//            else if (ch == 4)
//            {
//                p.calEvnt += new cal(Publisher.div);
//                p.consumer();
//            }
//            //else if (ch == 5)
//            //    break;
//            else
//                Console.WriteLine("Invalid Choice made");


//            //}
//        }

//    }
//}












//using System;

//namespace Prj1Day1Con
//{
//    public delegate void cal(int a, int b);


//    class Program
//    {
//        public void add(int a, int b) { Console.WriteLine("In sum function: Result:  " + (a + b)); }
//        public static int mul(int a, int b) { Console.WriteLine("In mul function"); return a * b; }
//        public void sub(int a, int b) { Console.WriteLine("In sub function: Result:  " + (a > b ? a - b : b - a)); }
//        public static int div(int a, int b) { Console.WriteLine("In div function"); return b == 0 ? 0 : a / b; }


//        static void Main(string[] args)
//        {
//            int ch = 0;
//            Program p = new Program();
//            cal cfn = new cal(p.add);
//            cfn += new cal(p.sub); //multi delegate
//            cfn(5, 8);

//        }

//    }
//}








// Delegates


//using System;

//namespace Prj1Day1Con
//{
//    public delegate int cal(int a, int b);


//    class Program
//    {
//        public int add(int a, int b) { return a + b; }
//        public static int mul(int a, int b) { return a * b; }
//        public int sub(int a, int b) { return a > b ? a - b : b - a; }
//        public static int div(int a, int b) { return b == 0 ? 0 : a / b; }

//        public void calculator(cal fn)
//        {
//            Console.WriteLine("Enter the first num:");
//            int x = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter the second num:");
//            int y = Convert.ToInt32(Console.ReadLine());
//            int res = fn(x, y);
//            Console.WriteLine("Result is: " + res);
//        }
//        static void Main(string[] args)
//        {
//            int ch = 0;
//            Program p = new Program();
//            cal cfn = new cal(p.add);
//            //cfn(8, 9);
//            while (true)
//            {
//                Console.WriteLine("Menu: \n1. Add\n2. Sub\n3. Mul\n4. Div\n5. Exit\nEnter Choice:");
//                ch = Convert.ToInt32(Console.ReadLine());
//                if (ch == 1)
//                {
//                    cfn = new cal(p.add);
//                }
//                else if (ch == 2)
//                {
//                    cfn = new cal(p.sub);
//                }
//                else if (ch == 3)
//                {
//                    cfn = new cal(mul);
//                }
//                else if (ch == 4)
//                {
//                    cfn = new cal(div);
//                }
//                else if (ch == 5)
//                    break;
//                else
//                    Console.WriteLine("Invalid Choice made");
//                p.calculator(cfn);

//            }
//        }

//    }
//}











//using System;

//namespace Prj1Day1Con
//{
//    struct Emp
//    {
//        public int id;
//        public string name;
//        public Emp(int id, string name) { this.id = id; this.name = name; }
//        public override string ToString() { return "Emp with ID: " + id + "has name : " + name; }

//    }

//    class Program
//    {

//        static void Main(string[] args)
//        {
//            Emp e1;
//            e1.id = 101;
//            e1.name = " Guest1";
//            Console.WriteLine(e1);

//            Emp e2 = new Emp();
//            e2.id = 102;
//            e2.name = " Guest2";
//            Console.WriteLine(e2);

//            Emp e3 = new Emp(103, "Guest3");
//            Console.WriteLine(e3);

//        }

//    }
//}









//using System;
//using System.Collections.Generic;

//class Program

//{
//    class Employee
//    {
//        public string Name { get; set; }
//        public int Age { get; set; }

//        public Employee(string name, int age)
//        {
//            Name = name;
//            Age = age;
//        }
//    }


//    class AgeException : ApplicationException
//    {
//        string message;
//        public AgeException()
//        {
//            message = "Invalid Age Entered: Age should be in range of 18 to 60.";
//        }
//        public AgeException(string message)
//        {
//            this.message = message + " :Age Exception.";

//        }
//        public override string ToString()
//        {
//            return message;

//        }

//        class DuplicateNameException : ApplicationException
//        {
//            string message;
//            public DuplicateNameException()
//            {
//                message = "Invalid Name entered: The name is already entered.";
//            }

//            public DuplicateNameException(string message)
//            {
//                this.message = message + " : Duplicate Name Exception";

//            }

//            public override string ToString()
//            {
//                return message;

//            }

//        }



//        static void Main(string[] args)
//        {
//            List<Employee> employees = new List<Employee>();

//            while (true)
//            {
//                Console.WriteLine("Menu:");
//                Console.WriteLine("1. Enter new Employee");
//                Console.WriteLine("2. List Employees");
//                Console.WriteLine("3. Exit");
//                Console.Write("Enter your choice: \n");

//                int choice = int.Parse(Console.ReadLine());

//                switch (choice)
//                {
//                    case 1:
//                        try
//                        {
//                            Console.Write("Enter Employee name: ");
//                            string name = Console.ReadLine();
//                            try
//                            {
//                                if (employees.Exists(e => e.Name == name))
//                                {
//                                    throw new DuplicateNameException();
//                                }
//                            }
//                            catch(DuplicateNameException dn)
//                            {
//                                Console.WriteLine("The Name is already added: "+dn.Message);
//                            }


//                            Console.Write("Enter Employee age: ");
//                            int age = int.Parse(Console.ReadLine());
//                            try
//                            {
//                                if (age < 18)
//                                {
//                                    throw new AgeException("Children not allowed as an Employee");
//                                }
//                                else if (age > 60)
//                                {
//                                    throw new AgeException("Seniors not allowed as an Employee");
//                                }
//                                else if (age > 100)
//                                {
//                                    throw new AgeException("Purvaj not allowed as an Employee");
//                                }

//                            }
//                            catch(AgeException ag)
//                            {
//                                Console.WriteLine("Please enter valid age "+ag.message);

//                            }


//                        employees.Add(new Employee(name, age));

//                    }
//                        catch (AgeException ex)
//                        {
//                            Console.WriteLine(ex.message);
//                        }
//                        break;

//                    case 2:
//                        Console.WriteLine("List of Employees:");
//                        foreach (var employee in employees)
//                        {
//                            Console.WriteLine($"Name: {employee.Name}, Age: {employee.Age}");
//                        }
//                        break;

//                    case 3:
//                        Console.WriteLine("Exiting program.");
//                        Environment.Exit(0);
//                        break;

//                    default:
//                        Console.WriteLine("Invalid choice. Please select a valid option.");
//                        break;
//                }
//            }
//        }
//    }
//}




















//using System;

//namespace Prj1Day1Con
//{
//    class AgeException : ApplicationException
//    {
//        string msg;
//        public AgeException()
//        {
//            msg = "Invalid Age : Age should be between 0-150";
//        }
//        public AgeException(string msg)
//        {
//            this.msg = msg + " : Age Exception";
//        }
//        public override string ToString()
//        {
//            return msg;
//        }

//    }
//    class Person
//    {
//        string name;
//        int age;
//        public Person() { name = "Guest"; age = 0; }
//        public Person(string name, int age)
//        {
//            this.name = name;
//            this.age = age;
//            if (age < 0 || age > 150)
//            {
//                throw new AgeException();
//            }
//        }
//        public override string ToString()
//        {
//            return "Person Name: " + name + "  and age : " + age;
//        }

//    }

//    class Program
//    {

//        static void Main()
//        {
//            try
//            {
//                Person p = new Person("Abc", 180);
//                Console.WriteLine(p);
//            }
//            catch (AgeException ex)
//            {
//                Console.WriteLine(ex);
//            }
//        }

//    }
//}
















//using System;

//namespace Prj1Day1Con
//{


//    class Program
//    {

//        static void Main()
//        {
//            int age;
//            Console.WriteLine("Enter Age:");
//            age = Convert.ToInt32(Console.ReadLine());
//            try
//            {
//                if (age < 0)
//                    throw new ArithmeticException("Invalid age - being negative");
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(ex.Message);
//            }

//        }

//    }
//}








//using System;
//using System.Collections.Generic;

//class Program
//{
//    static void Main(string[] args)
//    {
//        try
//        {
//            Console.WriteLine("Enter a comma-separated list of topic name and hours" +
//                " (e.g., Java 24, JEE 10, JME 12):");
//            string input = Console.ReadLine();

//            string[] inputArray = input.Split(',');

//            Dictionary<string, int> topics = new Dictionary<string, int>();

//            // Parse the input into topic name and hours, and add to the dictionary
//            for (int i = 0; i < inputArray.Length; i += 2)
//            {
//                string topic = inputArray[i].Trim();
//                int hours = int.Parse(inputArray[i + 1].Trim());
//                topics[topic] = hours;
//            }

//            // Calculate topics covered day-wise
//            int hoursInADay = 8;

//            foreach (var topic in topics)
//            {
//                int days = (int)Math.Ceiling((double)topic.Value / hoursInADay);
//                Console.WriteLine($"{topic.Key}: {days} days training");
//            }
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine($"An error occurred: {ex.Message}");
//        }
//    }
//}












//using System;

//namespace Prj1Day1Con
//{


//    class Program
//    {

//        static void Main()
//        {
//            int[] x = new int[5];  //x[0] to x[4]
//            int d = 2;
//            try
//            {
//                try
//                {
//                    Console.WriteLine("Enter a number: numerator : ");
//                    x[5] = Convert.ToInt32(Console.ReadLine());
//                    Console.WriteLine("Enter another number: denominator : ");
//                    d = Convert.ToInt32(Console.ReadLine());
//                    Console.WriteLine("The square of the number enetered is : " + (d * d));
//                    int y = x[5] / d;
//                    Console.WriteLine("Div Result: " + y);

//                }
//                catch (FormatException e)
//                {
//                    Console.WriteLine("This is a " + e.Message + " exception!");
//                    int p = d / 0;

//                }
//                catch (DivideByZeroException e)
//                {
//                    Console.WriteLine("This is a " + e.Message + " exception!");
//                }
//                catch (Exception e)
//                {
//                    Console.WriteLine("This is a " + e.Message + " exception!");
//                }
//            }
//            catch (Exception e)
//            {
//                Console.WriteLine("Outer Catch: This is a " + e.Message + " exception!");
//            }

//        }

//    }
//}









//using System;

//namespace Prj1Day1Con
//{
//    class Resource
//    {
//        public void work()
//        {
//            Console.WriteLine("Some task done by the resource");
//        }
//        public void closure()
//        {
//            Console.WriteLine("Resource Shut down...");
//        }

//    }


//    class Program
//    {
//        static int div(int a, int b, Resource r)
//        {
//            r.work();
//            try
//            {
//                Console.WriteLine("try: Division of : {0} / {1} : ", a, b);
//                return a / b;
//            }
//            catch (DivideByZeroException e)
//            {
//                Console.WriteLine("catch: Divison by zero not possible, so res is 0");
//                return 0;
//            }
//            finally
//            {
//                Console.WriteLine("finally: the resource will be closed");
//                r.closure();
//            }
//        }
//        static void Main()
//        {
//            Resource r = new Resource();
//            int res = div(10, 2, r);
//            Console.WriteLine(res);
//            res = div(10, 0, r);
//            Console.WriteLine(res);


//        }

//    }
//}











//using System;

//namespace Prj1Day1Con
//{
//    class Resource
//    {
//        public static void work()
//        {
//            Console.WriteLine("Some task done by the resource");
//        }
//        public static void closure()
//        {
//            Console.WriteLine("Resource Shut down...");
//        }

//    }
//    class Program
//    {
//        static void Main()
//        {
//            int x = 10;
//            int d = 2;

//            try
//            {
//                Resource.work();
//                Console.WriteLine("Enter a number: numerator : ");
//                x = Convert.ToInt32(Console.ReadLine());
//                Console.WriteLine("Enter another number: denominator : ");
//                d = Convert.ToInt32(Console.ReadLine());
//                Console.WriteLine("The square of the number enetered is : " + (x * x));
//                int y = x / d;
//                Console.WriteLine("Div Result: " + y);

//            }
//            catch (FormatException e)
//            {
//                Console.WriteLine("This is a " + e.Message + " exception!");

//            }
//            catch (DivideByZeroException e)
//            {
//                Console.WriteLine("This is a " + e.Message + " exception!");
//            }
//            finally
//            {
//                Resource.closure();
//            }
//            Console.WriteLine("The Program continues..");

//        }

//    }
//}










//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int x = 10;
//            int d = 2;

//            try
//            {
//                Console.WriteLine("Enter a number: numerator : ");
//                x = Convert.ToInt32(Console.ReadLine());
//                Console.WriteLine("Enter another number: denominator : ");
//                d = Convert.ToInt32(Console.ReadLine());
//                Console.WriteLine("The square of the number enetered is : " + (x * x));
//                int y = x / d;
//                Console.WriteLine("Div Result: " + y);
//            }
//            catch (FormatException e)
//            {
//                Console.WriteLine("This is a " + e.Message + " exception!");
//            }
//            catch (DivideByZeroException e)
//            {
//                Console.WriteLine("This is a " + e.Message + " exception!");
//            }
//            Console.WriteLine("The Program continues..");

//        }

//    }
//}









//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            Console.WriteLine("Enter a number: numerator : ");
//            int x = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter another number: denominator : ");
//            int d = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("The square of the number enetered is : " + (x * x));
//            try
//            {
//                int y = x / d;
//                Console.WriteLine("Div Result: " + y);
//            }
//            catch (DivideByZeroException e)
//            {
//                Console.WriteLine("This is a " + e.Message + " exception!");
//            }
//            Console.WriteLine("The Program continues..");

//        }

//    }
//}










//using System;
//using System.Xml.Linq;


//namespace Prj1Day1Con
//{
//    class Ppl
//    {
//        public virtual void print()
//        {
//            Console.WriteLine("Emp: ID : and name : ");
//        }
//    }
//    class Emp : Ppl
//    {
//        public int Id { get; set; }
//        public string Name { get; set; }
//        public sealed override void print()
//        {
//            Console.WriteLine("Emp: ID : {0} and name : {1} ", Id, Name);
//        }
//    }
//    sealed class Mngr : Emp
//    {
//        //public override void print()
//        //{
//        //    Console.WriteLine("EmpMngr: ID : {0} and name : {1} ", Id, Name);
//        //}

//    }
//    //class HighMngmnt : Mngr
//    //{

//    //}

//    class Program
//    {
//        static void Main()
//        {
//            Emp emp = new Mngr();
//            emp.print();

//        }

//    }
//}








//using System;


//namespace Prj1Day1Con
//{


//    class Program
//    {
//        static void Main()
//        {
//            //int[,] a = { { 1, 2, 3 }, { 4, 5, 6 } };
//            //Console.WriteLine(a.Length);




//            // Declare the array of two elements.
//            int[][] arr = new int[2][];

//            // Initialize the elements.
//            arr[0] = new int[5] { 1, 3, 5, 7, 9 };
//            arr[1] = new int[4] { 2, 4, 6, 8 };

//            // Display the array elements.
//            for (int i = 0; i < arr.Length; i++)
//            {
//                System.Console.Write("Element({0}): ", i);
//                for (int j = 0; j < arr[i].Length; j++)
//                    System.Console.Write("{0}\t", arr[i][j]);
//                System.Console.WriteLine();
//            }
//            //System.Console.ReadKey();
//        }

//    }
//}








//using System;


//namespace Prj1Day1Con
//{
//    class Matrix
//    {
//        public const int SIZE = 3;
//        private int[,] matrix = new int[SIZE, SIZE];

//        public static void Initialize(Matrix mat)
//        {
//            for (int x = 0; x < Matrix.SIZE; x++)
//                for (int y = 0; y < Matrix.SIZE; y++)
//                    mat.matrix[x, y] = x + y;
//        }
//        public static void Print(Matrix mat)
//        {
//            for (int x = 0; x < Matrix.SIZE; x++)
//            {
//                for (int y = 0; y < Matrix.SIZE; y++)
//                    Console.Write("a[{0},{1}] = {2} \t", x, y, mat.matrix[x, y]);
//                Console.WriteLine();
//            }
//        }
//    }

//    class Program
//    {
//        static void Main()
//        {
//            //int[,] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 6, 7, 8 }, { 8, 9, 10 } };
//            Matrix mat1 = new Matrix();
//            Matrix.Initialize(mat1);
//            Console.WriteLine("Matrix: ");
//            Matrix.Print(mat1);

//        }
//    }
//}







//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Printer
//    {
//        static string driver;
//        public string doc;
//        public static void resetPrinter()
//        {
//            Console.WriteLine("The printer is reset");
//        }
//        static Printer()
//        {
//            driver = "HP Printer";
//            Console.WriteLine("The driver is loaded as :" + driver);
//        }
//        public Printer()
//        {
//            doc = "Default document";
//            Console.WriteLine("The driver {0} is prints the document: {1}", driver, doc);
//        }
//        public Printer(string doc)
//        {
//            this.doc = doc;
//            Console.WriteLine("The driver {0} is prints the document: {1}", driver, doc);
//        }
//    }
//    class Program
//    {
//        static void Main()
//        {
//            Printer.resetPrinter();
//            Printer p1 = new Printer();
//            Printer p2 = new Printer("This is a new Doc");

//        }
//    }
//}












//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Employee
//    {
//        public static string CompName;
//        public static void staticFn()
//        {
//            Console.WriteLine("Static function");
//        }
//        static Employee()
//        {
//            Console.WriteLine("Static Constructor called only once. Used to initialize static fields");
//            CompName = "PWC";
//        }
//        public Employee()
//        {
//            Console.WriteLine("Constructor called every time a new object is made.");
//        }
//    }
//    class Program
//    {
//        static void Main()
//        {
//            Employee.staticFn();
//            Employee e1 = new Employee();
//            Employee e2 = new Employee();
//        }
//    }
//}








//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Imag
//    {
//        public int Im { get; set; }
//        public string Ima { get { return "i " + Im; } }
//        public override string ToString()
//        {
//            return Ima;
//        }
//    }
//    class Complex
//    {
//        public int Real { get; set; }
//        public Imag Imag { get; set; }

//        public override string ToString()
//        {
//            return Real + " " + Imag;
//        }
//        public Complex() { }
//        //public Complex(Complex C) //shallow copy
//        //{
//        //    Real = C.Real;
//        //    Imag = C.Imag; //Object reference is copied
//        //}
//        public Complex(Complex C) //deep copy
//        {
//            Real = C.Real;
//            Imag = new Imag { Im = C.Imag.Im };
//        }
//    }

//    class Program
//    {
//        static void Main()
//        {
//            Imag i1 = new Imag { Im = 16 };
//            Complex c1 = new Complex { Real = 12, Imag = i1 };
//            Console.WriteLine("C1: " + c1);
//            Complex c2 = new Complex(c1);
//            Console.WriteLine("C2: " + c2);
//            c1.Real = 100;
//            i1.Im = 1111;
//            Console.WriteLine("Post change:\nC1: " + c1);
//            Console.WriteLine("C2: " + c2);

//            //int i = 10;
//            //int j = i;
//            //i = 30;
//            //Console.WriteLine(j);//j=10



//        }
//    }
//}










//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Complex
//    {
//        public int Real { get; set; }
//        public int Imag { get; set; }

//        public override string ToString()
//        {
//            return Real + " i" + Imag;
//        }
//        public Complex() { }
//        public Complex(Complex C)
//        {
//            Real = C.Real;
//            Imag = C.Imag;
//        }
//    }

//    class Program
//    {
//        static void Main()
//        {
//            Complex c1 = new Complex { Real = 12, Imag = 16 };
//            Console.WriteLine("C1: " + c1);
//            Complex c2 = new Complex(c1);
//            Console.WriteLine("C2: " + c2);
//            c1.Real = 100;
//            Console.WriteLine("Post change:\nC1: " + c1);
//            Console.WriteLine("C2: " + c2);

//            //int i = 10;
//            //int j = i;
//            //i = 30;
//            //Console.WriteLine(j);//j=10



//        }
//    }
//}








//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Complex
//    {
//        public int Real { get; set; }
//        public int Imag { get; set; }

//        public override string ToString()
//        {
//            return Real + " i" + Imag;
//        }
//    }

//    class Program
//    {
//        static void Main()
//        {
//            Complex c1 = new Complex { Real = 12, Imag = 16 };
//            Console.WriteLine(c1);

//        }
//    }
//}









//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Program
//    {

//        static void Main()
//        {
//            // int.MaxValue is 2,147,483,647.
//            const int ConstantMax = int.MaxValue;
//            const int ConstantMin = int.MinValue;
//            int int1;

//            // The following statements are checked by default at compile time. They do not compile.
//            //int1 = 2147483647 + 10;    
//            //int1 = ConstantMax + 10;

//            // To enable the assignments to int1 to compile and run, place them inside
//            // an unchecked block or expression. The following statements compile and run.
//            unchecked
//            {
//                int1 = 2147483647 + 10;
//                Console.WriteLine(int1);
//                Console.WriteLine("ConstMax: " + ConstantMax + " + 10 : " + int1);
//            }
//            int1 = unchecked(ConstantMax - 10);

//            // The sum of 2,147,483,647 and 10 is displayed as -2,147,483,639.
//            Console.WriteLine("ConstMin: " + ConstantMin + " - 10 : " + int1);


//        }
//    }
//}







//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Program
//    {

//        static void Main()
//        {
//            int? a = null;
//            int b = a ?? -1;
//            Console.WriteLine(b);  // output: -1
//            a = 20;
//            b = a ?? -1;
//            Console.WriteLine(b); //output: 20
//            Console.ReadLine();

//        }
//    }
//}








//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Animal
//    {
//        public void eat()
//        {
//            Console.WriteLine("Animals Eat");
//        }
//    }
//    class Dog : Animal
//    {
//        public void bark()
//        {
//            Console.WriteLine("Dogs Bark");
//        }
//    }
//    class Cat : Animal
//    {
//        public void meow()
//        {
//            Console.WriteLine("Cat Meows");
//        }
//    }
//    class Program
//    {

//        static void Main()
//        {
//            Animal a1 = new Dog();
//            a1.eat();
//            if (a1 is Dog) //is returns T or false by checking instance of class
//            {
//                Dog d = (Dog)a1;
//                d.bark();
//            }
//            Animal a2 = new Cat();
//            Cat c = a2 as Cat; // it is another form of is operator:
//                               // returns the casted object or null
//                               //as operator is same as:
//                               //Cat c = a2 is Cat? (Cat)a2 : null
//            if (c != null)
//            {
//                c.meow();
//            }

//        }
//    }
//}






//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    class Employee
//    {
//        //In the background this property is going to create a private string firstName, provide proper getter and setter code.
//        public string FirstName { get; set; }
//        private static int flag = 0;

//        private string lastName;
//        private string msg;
//        public string Msg
//        {
//            get
//            {
//                string m = msg;
//                if (flag == 0)
//                {
//                    Console.WriteLine("The msg is read only once?Y to continue:");
//                    string m2 = Console.ReadLine();
//                    if (m2 == "Y" || m2 == "y")
//                    {
//                        flag = 1;
//                        msg = "go went gone !!";
//                        return m;
//                    }
//                    else
//                        return "Try again to read";
//                }
//                else
//                {
//                    m = "go went gone!";
//                }
//                Console.Write("The message is: ");
//                return m;
//            }
//            set
//            {
//                msg = value;
//            }
//        }
//        public string LastName
//        {
//            get
//            {
//                return lastName;
//            }
//            set
//            {
//                lastName = value;
//            }
//        }

//        private int age;
//        public int Age
//        {
//            get
//            {
//                Console.WriteLine("\n\n\nThis age is read!!!\n\n");
//                return age;
//            }
//            set
//            {
//                if (value > 18 && value < 70)
//                    age = value;
//                else
//                    age = 0;
//            }
//        }
//        private string compName;
//        public Employee()
//        {
//            FirstName = "Abc";
//            LastName = "Xyz";
//            compName = "PWC";
//        }
//        public Employee(string cn)
//        {
//            compName = cn;
//        }
//        public string CompName { get { return compName; } }



//    }

//    class Program
//    {

//        static void Main()
//        {
//            Employee e1 = new Employee();
//            Employee e21 = new Employee();
//            e1.Age = -20;
//            int x;

//            string name = e1.CompName;
//            //e1.CompName = " blah";
//            e1.Msg = "Secret Message";

//            Console.WriteLine("The Emp details " + e1.FirstName + e1.LastName + e1.Age + e1.CompName);
//            while (true)
//            {
//                Console.WriteLine("Read message: Y/N");
//                string a = Console.ReadLine();
//                if (a == "N" || a == "n")
//                {
//                    break;
//                }
//                Console.WriteLine("\n\n\nMsg: \n\n\n" + e1.Msg);
//            }
//            Console.WriteLine("\n\n\nMsg from e2: \n\n\n" + e21.Msg);

//        }
//    }
//}










//using System;


//namespace Prj1Day5Con
//{
//    class CDROM
//    {



//        private string name;
//        public int id=1;
//        public int i=1;
//        public string Name { 
//            get
//            {
//                if (i>0)
//                {
//                    return name;
//                    i-=i;

//                }
//                else 
//                {
//                    return "The Name is already read.";
//                }


//            }
//            set
//            {
//                while(id>0)
//                {
//                    name = value;
//                    id=0;

//                }


//            }
//        }



//        public CDROM()
//        {
//             name= "Abc";

//        }
//        public CDROM(string n)
//        {
//            Name = n;
//        }



//    }

//    class Program
//    {

//        static void Main()
//        {
//            CDROM e1 = new CDROM();
//            e1.Name = "Dipankar";
//            e1.Name = "HII";


//            Console.WriteLine("The Name is: " + e1.Name);

//            Console.WriteLine("The Name is: " + e1.Name);

//        }
//    }
//}

















//using System;

//namespace Prj1Day5Con

//{
//    class Employee
//    {
//        //In the background this property is going to create a private string firstName, provide proper getter and setter code.
//        public string FirstName { get; set; }

//        private string lastName;
//        public string LastName
//        {
//            get
//            {
//                return lastName;
//            }
//            set
//            {
//                lastName = value;
//            }
//        }

//        private int age;
//        public int Age
//        {
//            get
//            {
//                return age;
//            }
//            set
//            {
//                if (value > 18 && value < 70)
//                    age = value;
//                else
//                    age = 0;
//            }
//        }
//        private string compName;
//        public Employee()
//        {
//            FirstName = "Abc";
//            LastName = "Xyz";
//            compName = "PWC";
//        }
//        public Employee(string cn)
//        {
//            compName = cn;
//        }
//        public string CompName { get { return compName; } }



//    }

//    class Program
//    {

//        static void Main()
//        {
//            Employee e1 = new Employee();
//            e1.Age = 40;
//            string name = e1.CompName;
//            //e1.CompName = " blah";

//            Console.WriteLine("The Emp details: " + "Name: "+e1.FirstName +" "+ e1.LastName + " Age: "+e1.Age +" Company: "+ e1.CompName);

//        }
//    }
//}