﻿





////Pa: public Google(), private CCard(), internal inHouseAlmirahGold(), protected FamilyBankAc, protected internal VehInsurance()
////Child: Pa  in the same domain:  no permission(object) required: public Google(), internal inHouseAlmirahGold(), protected FamilyBankAc, protected internal VehInsurance()
////Ma: in the same domain: permission(object) required: public Google(), internal inHouseAlmirahGold(), protected internal VehInsurance()
////FarAwayChild: Pa: no permission(object) required: public Google(), protected FamilyBankAc, protected internal VehInsurance()
////Friend: permission(object) required: public Google()









////We can override any function if the parent most class function is either abstract or virtual.
////So the first function in the hierarchy should be either virtual (for a non-abstract or concrete class)
//// or abstract (for an abstract class or an interface)
//// All other function overriding the parent functions should have the keyword override.
////Thus a function can use override keyword only if : 
//    // 1. If it's parent is override (ing) the grand parent function
//    //2. If the parent function is the first function in the hierarchy with vitual / abstract keyword.





//using System;
//using System.Reflection.Metadata.Ecma335;

//namespace Prj1Day1Con
//{
//    abstract class Animal
//    {
//        public abstract void handBone();
//    }

//    class Mammal : Animal
//    {
//        public override void handBone()
//        {
//            Console.WriteLine("Hand bones of Mammals");
//        }
//    }
//    class Human : Mammal
//    {
//        public override void handBone()
//        {
//            Console.WriteLine("Hand bones of Human : Working");
//        }
//    }
//    class HumanChild : Human
//    {
//        public override void handBone()
//        {
//            Console.WriteLine("Hand bones of Child : Coding");
//        }
//    }
//    class Bat : Mammal
//    {
//        public override void handBone()
//        {
//            Console.WriteLine("Hand bones of Bat : Flying");
//        }
//    }
//    class Lion : Mammal
//    {
//        public override void handBone()
//        {
//            Console.WriteLine("Hand bones of Lion : Walking");
//        }
//    }
//    class FossilStudy
//    {
//        public void findFossil(Mammal m)
//        {
//            m.handBone();
//        }
//    }
//    class Program
//    {

//        static void Main()
//        {
//            FossilStudy fossilStudy = new FossilStudy();
//            fossilStudy.findFossil(new Human());
//            fossilStudy.findFossil(new HumanChild());
//            fossilStudy.findFossil(new Lion());
//            fossilStudy.findFossil(new Bat());

//        }
//    }
//}













//using System;
//namespace Prj1Day1Con
//{
//    class Addition
//    {
//        //Compile time polymorphism:
//        //1. Case 1 and 2 are diff functions as their number of params are different
//        //Case 2 with case 3 are diff functions as their data type and number of params are different
//        //2. Case 1,3,4 and 5 are diff functions as their data type of params are different
//        //3. Case 4 and 5 are diff as the series of data type of param is diff
//        public void sum(int x, int y) //case 1
//        {
//            Console.WriteLine("sum(int {0}, int {1}) : {2}", x, y, (x + y));
//        }
//        public void sum(int x, int y, int z) //case 2
//        {
//            Console.WriteLine("sum(int {0}, int {1}, int {2}) : {3}", x, y, z, (x + y + z));
//        }
//        public void sum(string x, string y) //case 3
//        {
//            Console.WriteLine("sum(string  {0}, string {1}) :  {2}", x, y, (x + y));
//        }
//        public void sum(string x, int y) //case 4
//        {
//            Console.WriteLine("sum(string  {0}, int {1}) :  {2}", x, y, (x + y));
//        }
//        public void sum(int x, string y) //case 5
//        {
//            Console.WriteLine("sum(int  {0}, string {1}) :  {2}", x, y, (x + y));
//        }

//    }

//    class Program
//    {
//        static void Main()
//        {
//            Addition a = new Addition();
//            a.sum("dd", "gg");
//            a.sum(2, 5);
//            a.sum(1, "gh");
//            a.sum("jj", 8);
//            a.sum(2, 5, 8);
//        }
//    }
//}






//using System;

//public interface Imylterator
//{
//    int Next();
//    void Begin();
//    bool HasNext();
//}

//public class MyCollection
//{
//    private int[] arr = new int[10000];
//    private int tos = -1;
//    private int nav = -1;

//    public void Add(int i)
//    {
//        if (tos < 9999)
//        {
//            tos++;
//            arr[tos] = i;
//        }
//    }

//    public Imylterator GetIterator()
//    {
//        return new MyIterator(this);
//    }


//    public class MyIterator : Imylterator
//    {
//        private MyCollection collection;

//        public MyIterator(MyCollection c)
//        {
//            collection = c;
//        }

//        public int Next()
//        {
//            if (collection.tos != -1 && collection.nav <= collection.tos)
//            {
//                int result = collection.arr[collection.nav];
//                collection.nav++;
//                return result;
//            }
//            return -1;
//        }

//        public void Begin()
//        {
//            if (collection.tos > 0)
//            {
//                collection.nav = 0;
//            }
//        }

//        public bool HasNext()
//        {
//            return collection.nav <= collection.tos;
//        }
//    }

//}

//public class Program
//{
//    public static void Main()
//    {
//        MyCollection col1 = new MyCollection();


//        for (int i = 1; i <= 100; i++)
//        {
//            col1.Add(i);
//        }


//        Imylterator it = col1.GetIterator();
//        it.Begin();


//        while (it.HasNext())
//        {
//            int value = it.Next();
//            Console.WriteLine(value);
//        }
//    }
//}







//using Prj1Day1Con;
//using System;
//namespace Prj1Day1Con
//{
//    interface IOperation
//    {
//        int op(int o1, int o2);
//    }

//    class Sum : IOperation
//    {
//        public int op(int o1, int o2)
//        {
//            return o1 + o2;
//        }
//    }
//    class Mul : IOperation
//    {
//        public int op(int o1, int o2)
//        {
//            return o1 * o2;
//        }
//    }
//    class Div : IOperation
//    {
//        public int op(int o1, int o2)
//        {
//            if (o2 == 0)
//            {
//                Console.WriteLine("division by zero can't be evaluated.");
//                return 0;
//            }
//            return o1 / 02;
//        }
//    }
//    class Sub : IOperation
//    {
//        public int op(int o1, int o2)
//        {
//            return o1 - o2;

//        }
//    }

//    class MathOperation
//    {
//        private int o1;
//        private int o2;
//        private IOperation operation;

//        public MathOperation(int o1, int o2, IOperation operation)
//        {
//            this.o1 = o1;
//            this.o2 = o2;
//            this.operation = operation;
//        }

//        public void Operate()
//        {
//            int res = operation.op(o1, o2);
//            Console.WriteLine("The result is: " + res);
//        }

//    }
//    class Program
//    {
//        static void Main()
//        {
//            Console.WriteLine("Enter the first operand: ");
//            int o1 = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter the second operand: ");
//            int o2 = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter operator:\nSum-1\nMul-2\nSub-3\nDiv-4");
//            int operation = Convert.ToInt32(Console.ReadLine());
//            IOperation obj;
//            switch (operation)
//            {
//                case 1:
//                    obj = new Sum();
//                    break;
//                case 2:
//                    obj = new Mul();
//                    break;
//                case 3:
//                    obj = new Sub();
//                    break;
//                case 4:
//                    obj = new Div();
//                    break;
//                default:
//                    Console.WriteLine("Incorrect entered operator.");
//                    obj = new Sum();
//                    break;
//            }

//            MathOperation p = new MathOperation(o1, o2, obj);
//            p.Operate();

//        }

//    }



//}















//using System;
//namespace Prj1Day1Con
//{
//    interface IHotDrink
//    {
//        void prepare();
//        int price();
//    }

//    class Restaurant
//    {
//        IHotDrink h;
//        public Restaurant()
//        {
//            h = new Tea();
//        }
//        public Restaurant(IHotDrink h)
//        {
//            this.h = h;
//        }
//        public void serve()
//        {
//            h.prepare();
//            Console.WriteLine("Serving the drink!");
//        }
//        public void bill()
//        {
//            Console.WriteLine("Your bill amount is : " + h.price());
//        }

//    }
//    class Tea : IHotDrink
//    {
//        public void prepare()
//        {
//            Console.WriteLine("Preparing hot Tea!");
//        }
//        public int price()
//        {
//            return 65;
//        }
//    }
//    class Coffee : IHotDrink
//    {
//        public void prepare()
//        {
//            Console.WriteLine("Preparing hot Coffee!");
//        }
//        public int price()
//        {
//            return 199;
//        }
//    }
//    class Soup : IHotDrink
//    {
//        public void prepare()
//        {
//            Console.WriteLine("Preparing hot Soup!");
//        }
//        public int price()
//        {
//            return 299;
//        }
//    }
//    class Program
//    {
//        static void Main()
//        {
//            Restaurant cust1 = new Restaurant(new Tea());
//            cust1.serve();
//            cust1.bill();
//            Restaurant cust2 = new Restaurant(new Coffee());
//            cust2.serve();
//            cust2.bill();
//            Restaurant cust3 = new Restaurant(new Soup());
//            cust3.serve();
//            cust3.bill();
//            Restaurant cust4 = new Restaurant();
//            cust4.serve();
//            cust4.bill();
//        }
//    }
//}











//using System;
//namespace Prj1Day1Con
//{
//    interface Alive //100% abstract
//    {
//        void eat(); //public abstract method
//        void sleep();
//        void grow();
//    }
//    abstract class Animal : Alive //50% abstract class
//    {
//        public void eat()
//        {
//            Console.WriteLine("An animal is eating!");
//        }

//        public abstract void grow();

//        public virtual void sleep()
//        {
//            Console.WriteLine("An animal is sleeping!");
//        }
//        public abstract void walk();
//    }
//    class Dog : Animal
//    {
//        public void bark()
//        {
//            Console.WriteLine("A Dog is barking Bow Bow!");
//        }
//        public override void grow() { }
//        public override void sleep()
//        {
//            Console.WriteLine("A dog sleeps very lightly!");
//        }
//        public override void walk()
//        {
//            Console.WriteLine("A dog walks cautiously!");
//        }


//    }
//    class Cat : Animal
//    {
//        public override void grow() { }
//        public void meow()
//        {
//            Console.WriteLine("A Cat is meowing meow meow!");
//        }
//        public override void walk()
//        {
//            Console.WriteLine("A Cat walks with cat walk!");
//        }
//    }
//    class AnimalTrainer
//    {
//        public void train(Animal a)
//        {
//            a.eat();
//            a.sleep();
//            if (a is Dog)
//            {
//                Dog d = (Dog)a;  //parent is casted into child object : Downcasting
//                d.bark();

//            }
//            if (a is Cat)
//            {
//                Cat c = (Cat)a;
//                c.meow();

//            }
//        }
//    }
//    class Program
//    {
//        static void Main()
//        {
//            Animal tom = new Dog(); // Animal -> eat and sleep ; Cat -> eat, sleep, meow
//            tom.eat();
//            tom.sleep();
//            if (tom is Cat)
//            {
//                Cat c = (Cat)tom;
//                c.meow();
//            }
//            Animal tiger = new Dog(); //Dog object referred by Animal object; Upcasting
//            AnimalTrainer trainer = new AnimalTrainer();
//            trainer.train(tiger);

//        }
//    }
//}
















//using System;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{


//    class Shape
//    {


//        public virtual void getShape()
//        {
//            Console.WriteLine("It is the shape.");
//        }

//        class Trianle : Shape
//        {
//            public override void getShape()
//            {
//                Console.WriteLine("The shape is : Trianle");

//            }
//        }

//        class Rectanle : Shape
//        {
//            public override void getShape()
//            {
//                Console.WriteLine("The shape is : Rectangle");

//            }

//        }

//        class Circle : Shape
//        {
//            public override void getShape()
//            {
//                Console.WriteLine("The shape is : Circle");

//            }

//        }

//        class Line : Shape
//        {
//            public override void getShape()
//            {
//                Console.WriteLine("The shape is : Line");

//            }

//        }
//        class Square : Shape
//        {
//            public override void getShape()
//            {
//                Console.WriteLine("The shape is : Square");

//            }

//        }

//        class Color
//        {
//            public virtual void getColor()
//            {
//                Console.WriteLine("The color is in RGB range.");
//            }

//            public class Red : Color
//            {
//                public override void getColor()

//                {
//                    Console.WriteLine("The color is: Red");
//                }
//            }

//            public class Blue : Color
//            {
//                public override void getColor()

//                {
//                    Console.WriteLine("The color is: Blue");
//                }
//            }

//            public class Green : Color
//            {
//                public override void getColor()

//                {
//                    Console.WriteLine("The color is: Green");
//                }
//            }
//            public class Black : Color
//            {
//                public override void getColor()

//                {
//                    Console.WriteLine("The color is: Black");
//                }
//            }

//            public class White : Color
//            {
//                public override void getColor()

//                {
//                    Console.WriteLine("The color is: White");
//                }
//            }




//            class Paint
//            {
//                public void Draw(Shape s, Color c)

//                {
//                    s.getShape();
//                    c.getColor();
//                }

//            }

//            class Program
//            {
//                static void Main()
//                {
//                    Paint p1 = new Paint();
//                    Shape s1 = new Rectanle();
//                    Color c1 = new Blue();

//                    p1.Draw(s1, c1);


//                }
//            }
//        }
//    }
//}











//using System;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{
//    class Paint
//    {

//        public virtual void getShape()
//        {
//            Console.WriteLine("It is the Shape.");
//        }
//        public virtual void getColor()
//        {
//            Console.WriteLine("It is the color");
//        }

//    }

//    class Shape : Paint
//    {
//        string s;
//        string c;
//        public void trianle()
//        {
//            Console.WriteLine("The color is : Trianle");

//        }
//        public void rectanle()
//        {
//            Console.WriteLine("The shape is : Rectangle");

//        }

//        public void circle()
//        {
//            Console.WriteLine("The shape is : Circle");

//        }

//        public void line()
//        {
//            Console.WriteLine("The shape is : Line");

//        }
//        public void square()
//        {
//            Console.WriteLine("The shape is : Square");

//        }


//    }
//    class Color : Paint
//    {
//        public void red()
//        {
//            Console.WriteLine("The color is: Red");
//        }

//        public void black()
//        {
//            Console.WriteLine("The color is: Black");
//        }

//        public void white()
//        {
//            Console.WriteLine("The color is: White");
//        }

//        public void green()
//        {
//            Console.WriteLine("The color is: Green");
//        }

//        public void blue()
//        {
//            Console.WriteLine("The color is: Blue");
//        }
//    }

//class Draw
//{

//        public class draw() 
//        {
//        }
//        public void draw(Paint s,Paint c)

//        {

//            s.getShape();
//            c.getColor();

//            if (s="Trianle")
//            {
//                Shape sh = (Shape)s;
//                sh.trianle();

//            }

//            else if (s == "Rectanle")
//            {
//                Shape sh = (Shape)s;
//                sh.rectanle();

//            }
//            else if (s == "Circle")
//            {
//                Shape sh = (Shape)s;
//                sh.circle();

//            }
//            else if (s == "Line")
//            {
//                Shape sh = (Shape)s;
//                sh.line();

//            }
//            else if (s == "Square")
//            {
//                Shape sh = (Shape)s;
//                sh.square();

//            }

//            if (c = "Red")
//            {
//                Color cl = (Color)c;
//                cl.red();

//            }
//            else if (c = "Blue")
//            {
//                Color cl = (Color)c;
//                cl.blue();

//            }
//            else if (c = "Green")
//            {
//                Color cl = (Color)c;
//                cl.green();

//            }
//            else if (c = "White")
//            {
//                Color cl = (Color)c;
//                cl.white();

//            }
//           else if (c = "Black")
//            {
//                Color cl = (Color)c;
//                cl.black();

//            }


//        }
//}


//class Program
//{
//    static void Main()
//    {
//        Paint s1 = new Shape();
//        Paint c1 = new Shape();

//        Draw p = new Draw();

//        p.draw("Rectanle","Blue");

//    }
//}








//using System;

//namespace Prj1Day1Con
//{
//    class Distance
//    {
//        int km;
//        int m;
//        public Distance() { }
//        public Distance(int km, int m)
//        {
//            this.m = m;
//            this.km = km;
//        }
//        public static Distance operator -(Distance d)
//        {
//            d.m = -d.m;
//            d.km = -d.km;
//            return d;
//        }

//        public override string ToString()
//        {
//            return "\nCurrent distance is:  " + km + " km and " + m + " meters.\n";
//        }
//    }

//    class Program
//    {
//        static void Main()
//        {
//            Distance d1 = new Distance(300, 20);
//            Distance d2 = new Distance(80, 30);
//            Console.WriteLine("D2 without Negation: " + d2);
//            d2 = -d2;
//            Console.WriteLine("D2 post Negation: " + d2);
//        }
//    }
//}
















//using System;
//namespace Prj1Day1Con
//{
//    class Animal
//    {
//        public void eat()
//        {
//            Console.WriteLine("An animal is eating!");
//        }
//        public virtual void sleep()
//        {
//            Console.WriteLine("An animal is sleeping!");
//        }
//    }
//    class Dog : Animal
//    {
//        public void bark()
//        {
//            Console.WriteLine("A Dog is barking Bow Bow!");
//        }
//        public override void sleep()
//        {
//            Console.WriteLine("A dog sleeps very lightly!");
//        }

//    }
//    class Cat : Animal
//    {
//        public void meow()
//        {
//            Console.WriteLine("A Cat is meowing meow meow!");
//        }
//    }
//    class AnimalTrainer
//    {
//        public void train(Animal a)
//        {
//            a.eat();
//            a.sleep();
//            if (a is Dog)
//            {
//                Dog d = (Dog)a;  //parent is casted into child object : Downcasting
//                d.bark();

//            }
//            if (a is Cat)
//            {
//                Cat c = (Cat)a;
//                c.meow();

//            }
//        }
//    }
//    class Program
//    {
//        static void Main()
//        {
//            Animal tiger = new Dog(); //Dog object referred by Animal object; Upcasting
//            AnimalTrainer trainer = new AnimalTrainer();
//            trainer.train(tiger);

//            Animal tom = new Cat(); //Cat object referred by Animal object; Upcasting
//            AnimalTrainer tra = new AnimalTrainer();
//            tra.train(tom);


//        }
//    }
//}











//using System;
//using System.Security.Cryptography;

//namespace Prj1Day1Con
//{
//    class Student
//    {
//        int StdId;
//        string StdName;
//        string StdCourse;
//        int durationDays;


//        public void input(int StdId, string StdName, string StdCourse, int duirationdays)
//        { 
//            this.StdId = StdId;
//            this.StdName = StdName;
//            this.StdCourse = StdCourse;
//            this.durationDays = duirationdays;

//        }
//        public Student() 
//        {
//            StdId = 102119016;
//            StdName = "Dipankar Adhikary";
//            StdCourse = "B.Tech";
//            durationDays = 4;
//        }

//        public override string ToString()
//        {
//            return "Student Id: " +StdId + "\nName: " +
//                StdName+"\nCourse: "+StdCourse+"\nDuration: "+durationDays+" Yeras";
//        }
//    }

//    class Program
//    {
//        static void Main()
//        {
//            Student s1 = new Student();
//            Console.WriteLine(s1);

//        }
//    }
//}




















//using System;
//namespace Prj1Day1Con
//{
//    class Emp
//    {
//        int id;
//        string name;
//        public Emp() { }
//        public Emp(int id, string name) { this.id = id; this.name = name; }

//        public override string ToString()
//        {
//            return "Emp : Id :" + id + " Name : " + name;
//        }
//    }
//    class SalEmp : Emp
//    {

//    }
//    class WagesEmp : Emp
//    {

//    }
//    class Program
//    {
//        static void Main()
//        {
//            SalEmp e1 = new SalEmp();
//            Console.WriteLine("e1 is Emp ??" + (e1 is Emp));
//            Console.WriteLine("e1 is Object ??" + (e1 is Object));
//            Console.WriteLine("e1 is SalEmp ??" + (e1 is SalEmp));
//            Console.WriteLine("e1 is WagesEmp ??" + (e1 is WagesEmp));

//        }
//    }
//}











//using System;
//namespace Prj1Day1Con
//{
//    class Emp //blue print of any object of type Emp. It is the encapsulated form of the class Emp
//    {
//        private int id; //data hiding
//        private string name;
//        public void input(int id, string name) //data abstraction
//        {
//            this.id = id;
//            this.name = name;
//        }
//        public Emp() //Constructor
//        {
//            id = 100;
//            name = "Guest";
//        }
//        public Emp(int id, string name) //data abstraction //parameterized Constructor
//        {
//            this.id = id;
//            this.name = name;
//        }
//        public override string ToString()   //Overriden ToString()
//        {
//            return "Current Emp details: Id : " + id + " Name : " + name;
//        }

//    }
//    class Program
//    {
//        static void Main()
//        {
//            Emp e1 = new Emp(); //new assigns space for an object in memory
//            Emp e2 = new Emp(102, "Abc");
//            Console.WriteLine(e1);
//            Console.WriteLine(e2);

//        }
//    }
//}






//using System;
//using System.ComponentModel.DataAnnotations;
//using System.Diagnostics.CodeAnalysis;
//using System.Linq;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{

//    class Program
//    {

//        static int sum(params int[] i)
//        {
//            int sum = 0;
//            for (int k = 0; k < i.Length; k++) sum += i[k];
//            return sum;
//        }
//        public static void Main()
//        {
//            int[] a = new int[] { 1, 4, 2, 8, 9, 4, 5, 67, 776, 66,1,87 };
//            Console.WriteLine("The min value is: "+a.Min());
//            Console.WriteLine("The sum of array a is: "+sum(a));
//        }
//    }
//}






















//using System;
//using System.Diagnostics.CodeAnalysis;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{

//    class Program
//    {
//        static int sum2(int[] arr)
//        {
//            int sum = 0;
//            for (int k = 0; k < arr.Length; k++) sum += arr[k];
//            return sum;
//        }
//        static int sum(params int[] i)
//        {
//            int sum = 0;
//            for (int k = 0; k < i.Length; k++) sum += i[k];
//            return sum;
//        }
//        public static void Main()
//        {
//            int[] a = new int[] { 1, 4, 2, 8, 9 ,4,5,67,776,66};
//            int s = sum(1, 2, 3, 4); //10  //possible in params, not possible in array
//            Console.WriteLine(s);
//            s = sum2(new int[] { 1, 2, 3, 4 ,87,9,5,7}); //10
//            Console.WriteLine(s);
//            s = sum(a); //24  //possible in params
//            Console.WriteLine(s);
//            s = sum2(a); //24
//            Console.WriteLine(s);
//            s = sum(11, 22); //33
//            Console.WriteLine(s);
//        }
//    }
//}











//using System;
//using System.Diagnostics.CodeAnalysis;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{

//    class Program
//    {
//        static public void scholar(string fname, string lname, int age = 20,
//          string branch = "Computer science")
//        {
//            Console.WriteLine("Name: {0} {1}", fname, lname);
//            Console.WriteLine("Age: {0} \n Branch: {1}", age, branch);
//        }
//        static void Main()
//        {
//            scholar("FN1", "LN1"); //using both age and branch default values
//            scholar("FN2", "LN2", 22); //using only branch default value
//            scholar("FN3", "LN3", 30, "IT"); //Providing all values
//                                             //scholar("FN3", "LN3", "IT"); //Error: third parameter is an int; while string is passed
//        }

//    }
//}






//using System;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{

//    class Program
//    {
//        static void fn1(out int a)
//        {
//            a = Convert.ToInt32(Console.ReadLine());

//            Console.WriteLine("The Square: {0} , Cube: {1} , 10*X : {2}",a*a,a*a*a,10*a);

//        }

//        static void fn2()
//        {
//            Console.WriteLine("Enter the number to display mutiplication table: ");
//            int b = Convert.ToInt32(Console.ReadLine());


//            for (int i = 1;i<=b;i++)
//            {

//                Console.WriteLine(b+"X"+i+" = "+(i*b));
//            }


//        }

//        static void fn3(int c ,int d)
//        {

//            Console.WriteLine("{0}*{1} : {2}", c, d, c*d);

//        }

//        static void fn4(ref int e, ref int f)
//        {
//            Console.WriteLine("Before swaping the pair is: ({0},{1})",e,f);
//            int s = e + f;
//            int x = s - e;
//            int y = s - f;

//            Console.WriteLine("Before swaping the pair is: ({0},{1})", x, y);

//        }

//        static void Main(String[] args)
//        {

//            Console.WriteLine("The given number  sqr, cube and 10*x is given below: ");
//            //int a = Convert.ToInt32(Console.ReadLine());
//            int a;
//            fn1(out a);

//            fn2();

//            Console.WriteLine("Enter the numbers to multiply: ");
//            Console.WriteLine("Enter the first number: ");

//            int c=Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter the first number: ");

//            int d = Convert.ToInt32(Console.ReadLine());
//            fn3(c,d);

//            Console.WriteLine("Enter the numbers to swap: ");
//            Console.WriteLine("Enter the first number: ");

//            int e = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter the first number: ");

//            int f = Convert.ToInt32(Console.ReadLine());
//            fn4(ref e, ref f);
//        }

//    }


//}











//using System;


//using System.Diagnostics.CodeAnalysis;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{
//    class A
//    {
//        public int a;
//    }
//    class Program
//    {
//        //four modifiers for functions:
//        //1. value for primitives/Reference for objects: default way of using parameters
//        //2. in : this clause makes the parameter readonly; not modified in the function
//        //3. out : the result expected from a function. no input value required
//        //4. ref : even the values for primitives are called by reference
//        static void fn1(int a)
//        {
//            Console.WriteLine("fn1 : " + a);
//            a = a + 10;
//            Console.WriteLine("fn1 modified : " + a);
//        }
//        static void fn1(A a)
//        {
//            Console.WriteLine("fn1 : " + a.a);
//            a.a = a.a + 10;
//            Console.WriteLine("fn1 modified : " + a.a);
//        }
//        static void fn2(in int a)
//        {
//            Console.WriteLine("fn2 : " + a);
//            int b = a;
//            //a =a+10; //assignment not possible
//        }
//        static void fn3(out int a)
//        {
//            a = 10;
//            int b = a;
//            Console.WriteLine("fn3 : " + a);

//        }
//        static void fn4(ref int a)
//        {
//            Console.WriteLine("fn4 : " + a);
//            a = a + 10;
//            Console.WriteLine("fn4 modified : " + a);

//        }

//        static void Main(string[] args)
//        {
//            int a = 10;
//            Console.WriteLine("Before Fn1: int a = " + a);
//            fn1(a);
//            Console.WriteLine("After Fn1: int a = " + a);
//            A oa = new A();
//            oa.a = 10;
//            Console.WriteLine("\nBefore Fn1: A oa'a = " + oa.a);
//            fn1(oa);
//            Console.WriteLine("After Fn1: A oa'a = " + oa.a);
//            Console.WriteLine("*********************");

//            int b = 10;
//            fn2(in b); //b should be assigned a value before fn call

//            int c;
//            fn3(out c); //ouput is expected from fn3.

//            int p = 10;
//            fn4(ref p); //p must have a value;  plus p can change the value also in the fn call.








//        }
//    }
//}










//using System;

//namespace Factorial

//{

//    class Program

//    {

//        static void Main(string[] args)

//        {

//            Console.WriteLine("Enter a number: ");

//            int number = Convert.ToInt32(Console.ReadLine());

//            long fact = Fact(number);

//            Console.WriteLine("{0} factorial is {1}", number, fact);

//        }

//        public static long Fact(int number)

//        {

//            if (number == 0)

//            { 
//                return 1;

//            }
//            return number * Fact(number - 1);

//        }

//    }

//}












//using System;
//using System.Diagnostics.CodeAnalysis;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static int c = 0;

//        static string find(int a, int[] arr, int l)
//        {
//            Console.WriteLine("Data search : #" + c++);
//            if (a == arr[l - 1])
//            {
//                return a + " is Found";
//            }
//            else if (c == arr.Length)
//            {
//                return a + " is not found";
//            }
//            else
//            {
//                return find(a, arr, l - 1);
//            }


//        }


//        static void fn(int i)
//        {
//            Console.WriteLine("Iteration: {0}", i);
//            if (i > 0)
//                fn(i - 1);
//        }
//        //sum of natural num series : sum(n) : 1+2+..n  = n + sum(n-1) till sum(1)
//        static int sum(int n)
//        {
//            if (n <= 0) return 0;
//            return n + sum(n - 1);
//        }

//        static void Main(string[] args)
//        {
//            int[] arr = { 1, 9, 3, 8, 5, 6, 7, 8, 2, 6 };
//            string s = find(10, arr, arr.Length);
//            Console.WriteLine(s);
//            Console.WriteLine("Recusive Call:");
//            fn(5);
//            Console.WriteLine("Recusive sum Call:\nSum(5) : " + sum(5));

//        }
//    }
//}




















//using System;
//using System.Diagnostics.CodeAnalysis;
//using System.Net;
//using System.Security.Cryptography.X509Certificates;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static int c = 0;

//        static string find(int a, int[] arr, int l)
//        {
//            Console.WriteLine("\nData search : #" + c++);
//            if (a == arr[l - 1])
//            {
//                return a + " is Found";
//            }
//            else if (c == arr.Length)
//            {
//                return a + " is not found";
//            }
//            else
//            {
//                return find(a, arr, l - 1);
//            }


//        }
//        static void Main(string[] args)
//        {
//            int[] arr = { 1, 9, 3, 8, 5, 6, 7, 8, 2, 6 };
//            string s = find(1, arr, arr.Length);
//            Console.WriteLine(s);
//        }
//    }
//}





//using System;
//using System.Diagnostics.CodeAnalysis;
//using System.Net;

//namespace Prj1Day1Con
//{
//    class Program
//    {

//        int sum(int a, int b)
//        {
//            int c = a + b;
//            return c;

//        }
//        static int add(int a, int b)
//        {
//            return a + b;
//        }
//        static void Main(string[] args)
//        {
//            Program p = new Program();
//            int res = add(3, 4);
//            int r = p.sum(6, 7);
//            int re = Program.add(1, 4);
//            Console.WriteLine(res + "   " + re + " " + r);

//        }
//    }
//}










//using System;
//using System.Net;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {



//            int arg1 = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("The first number : " + Convert.ToString(arg1));

//            int arg2 = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("The second number : " + Convert.ToString(arg2));
//            if(arg1 > arg2)
//            {
//                int n1=arg2;
//                int n2 = arg1;

//                int cnt;

//                for (int i = n1; i <= n2; i++)

//                {
//                    cnt = 0;

//                    for (int j = 2; j <= i / 2; j++)
//                    {
//                        if (i % j == 0)
//                        {
//                            cnt++;
//                            break;

//                        }
//                    }


//                    if (cnt == 0 && i != 0)
//                    {
//                        Console.WriteLine("{0} ", i);

//                    }


//                }


//            }
//            else
//            {
//                int cnt;

//                for (int i = arg1; i <= arg2; i++)

//                {
//                    cnt = 0;

//                    for (int j = 2; j <= i / 2; j++)
//                    {
//                        if (i % j == 0)
//                        {
//                            cnt++;
//                            break;

//                        }
//                    }


//                    if (cnt == 0 && i != 0)
//                    {
//                        Console.WriteLine("{0} ", i);

//                    }


//                }

//            }



//        }
//    }
//}














//using System;
//using System.Net;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            if(args.Length >= 2 || args.Length <=2) 
//            {
//                Console.WriteLine("The length of the args are out of the range.");

//            }

//            int arg1 = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("The arg 1 : " + Convert.ToString(arg1));

//            int arg2 = Convert.ToInt32(Console.ReadLine()) ;
//            Console.WriteLine("The arg 2 : "+Convert.ToString(arg2));

//            Console.WriteLine("The sum of the arg1 and arg2 is : "+(arg1 + arg2));


//            }
//        }
//}





















//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {

//        static void Main()
//        {

//            int n = 3;


//            for (int i=0; i<3; i++)
//            {
//                Console.WriteLine("Enter your username: ");
//                String name = Console.ReadLine();
//                Console.WriteLine("Enter your Password: ");
//                String pass = Console.ReadLine();

//                if (pass == "Adhikary" && name=="Dipankar")
//                {
//                    Console.WriteLine("Yor are logged in to the system.");
//                    break;
//                }

//                else 
//                {

//                    Console.WriteLine("Your name or password is wrong, please enter right name or password.\nTry againg to log in.");
//                    n -= n;
//                    continue;
//                }
//            }
//            if (n == 0)
//            {
//                Console.WriteLine("Your all of chances are lost.\n An error is occured when loing to the system.");
//            }
//        }
//    }
//}
























//Rules:
//declare the class as sealed so it cannot be extended
//all class members should be private and readonly so they cannot be accessed outside of class
//shouldn't contain any setter methods to change the value of class members
//the getter method should return the copy of class members
//class members are only initialized using constructor








//using System;


//namespace Prj1Day1Con
//{
//    class Address
//    {
//        private string add;
//        public Address()
//        {
//            add = "IDK";
//        }
//        public Address(string add)
//        {
//            this.add = add;
//        }
//        public void setAdd(string add) { this.add = add; }
//        public string getAdd() { return add; }

//    }
//    class Employee
//    {
//        private readonly int id;
//        private readonly string name;
//        private readonly Address address;
//        public Employee()
//        {
//            id = 101;
//            name = "IDK";
//            address = new Address();
//        }
//        public Employee(int id, string name, Address address)
//        {
//            this.id = id;
//            this.name = name;
//            this.address = new Address(address.getAdd());
//        }
//        public String getValues()
//        {
//            return "Id : " + getId() + " name : " + getName() + " address : " + getAddress().getAdd();
//        }
//        public int getId() { return id; }
//        public string getName() { return name; }
//        public Address getAddress() { return new Address(address.getAdd()); }

//    }
//    class Program
//    {
//        static void Main()
//        {
//            Address add = new Address("Delhi");
//            Employee e = new Employee(102, "Abc", add);
//            Console.WriteLine("Before add.setter: \n" + e.getValues());
//            add.setAdd("Kolkatta");
//            Console.WriteLine("After add.setter: \n" + e.getValues());
//            e.getAddress().setAdd("Mumbai");
//            Console.WriteLine("After using getAddress.setAdd(): \n" + e.getValues());
//        }
//    }
//}

/*

Before add.setter:
Id : 102 name : Abc address : Delhi
After add.setter:
Id : 102 name : Abc address : Delhi
After using getAddress.setAdd():
Id : 102 name : Abc address : Delhi


 */








//using System;

//namespace Prj1Day1Con
//{
//    class Address
//    {
//        private string add;
//        public Address()
//        {
//            add = "IDK";
//        }
//        public Address(string add)
//        {
//            this.add = add;
//        }
//        public void setAdd(string add) { this.add = add; }
//        public string getAdd() { return add; }

//    }
//    class Employee
//    {
//        private readonly int id;
//        private readonly string name;
//        private readonly Address address;
//        public Employee()
//        {
//            id = 101;
//            name = "IDK";
//            address = new Address();
//        }
//        public Employee(int id, string name, Address address)
//        {
//            this.id = id;
//            this.name = name;
//            this.address = address;  //Case 1
//            //the direct reference to address will make it changeable as the parameter is a reference type object 
//            //and has it's own heap reference, which means the if we change the parameter's heap, the immutable class 
//            //field also changes
//        }
//        public String getValues()
//        {
//            return "Id : " + getId() + " name : " + getName() + " address : " + getAddress().getAdd();
//        }
//        public int getId() { return id; }
//        public string getName() { return name; }
//        public Address getAddress()
//        {
//            return address; //case 2
//            //if direct reference to the field is returned, the heap it is refering to is also sent.
//            //the heap it is referring to is Mutable, so our field is also changed when we change the heap.
//        }

//    }
//    class Program
//    {
//        static void Main()
//        {
//            Address add = new Address("Delhi");
//            Employee e = new Employee(102, "Abc", add);
//            Console.WriteLine("Before add.setter: \n" + e.getValues());
//            add.setAdd("Kolkatta"); //Case 1 Problem, we are changing the heap of reffered object
//            Console.WriteLine("After add.setter: \n" + e.getValues());
//            e.getAddress().setAdd("Mumbai"); //case 2, we are getting the direct reference to the field, making it changeable
//            Console.WriteLine("After using getAddress.setAdd(): \n" + e.getValues());
//        }
//    }
//}

/*
 Before add.setter:
Id : 102 name : Abc address : Delhi
After add.setter:
Id : 102 name : Abc address : Kolkatta
After using getAddress.setAdd():
Id : 102 name : Abc address : Mumbai



 */






//1.Classes are sealed (cannot be further inheritance)
//2.All fields are private and readonly
//3.Getters for the fields (No Setter is allowed : since it’s readonly the setters are not applicable)
//4.If the reference of mutable object is used in immutable class, the do not refer to it in the constructor. Copy the value rather than the reference in the constructor.
//5. If getters are used for Mutable objects, then do not return the direct reference to the object.















//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {

//        static void Main()
//        {
//            int[] arr = { 12, 2, 39, 43, 51, 6 };
//            foreach (int ele in arr)
//            {
//                Console.WriteLine("Processing Element : " + ele);
//            }
//        }
//    }
//}






//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {

//        static void Main()
//        {
//            Console.Write("Iteration:");
//            for (int i = 0; i < 10; i++)
//            {
//                if (i == 4)
//                {
//                    continue;
//                }
//                if (i == 7)
//                    break;
//                Console.Write("\t" + i);
//            }
//            Console.WriteLine();
//            string name;
//            do
//            {
//                Console.WriteLine("Enter your name: (More than 2 char)");
//                name = Console.ReadLine();
//            } while (name.Length <= 2);

//            int age = -1;
//            while (age < 0 || age >= 65)
//            {
//                Console.WriteLine("Enter Age: (0-64)");
//                age = Convert.ToInt32(Console.ReadLine());
//                if (age < 0 || age > 150)
//                {
//                    Console.WriteLine("Ghosts are NOT allowed to use my S/W");
//                }
//                if (age >= 65 && age <= 150)
//                {
//                    Console.WriteLine("You Can Enjoy your Retirement Age..");
//                }
//            }
//            Console.WriteLine("Welcome {1}! You have {0} years for retirement!", (65 - age), name);
//        }
//    }
//}











//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        enum Weekday { Sun = 1, Mon, Tue, Wed, Thurs, Fri, Sat }
//        static void Main()
//        {
//            Console.WriteLine("Enter current Weekday(1 -7):");
//            int wd = Convert.ToInt32(Console.ReadLine());
//            switch (wd)
//            {
//                case 1:
//                    Console.WriteLine("First Day of the Week: " + (Weekday)wd);
//                    break;
//                case 2:
//                case 3:
//                case 4:
//                case 5:
//                case 6:
//                    Console.WriteLine("{0}th Day of the Week: {1}", wd, (Weekday)wd);
//                    break;
//                case 7:
//                    Console.WriteLine("Last Day of the Week: " + (Weekday)wd);
//                    break;
//                default:
//                    Console.WriteLine("Invalid Day number entered!");
//                    break;

//            }

//        }
//    }
//}








//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int marks = 90;
//            if (marks > 100)
//            {
//                Console.WriteLine("Invalid marks (more than 100)");

//            }
//            else if (marks < 0)
//            {
//                Console.WriteLine("Invalid marks(less than 0)");

//            }
//            else if (marks >= 0 && marks < 50)
//            {
//                Console.WriteLine("Failed!!!!!!");

//            }
//            else if (marks >= 50 && marks < 75)
//            {
//                Console.WriteLine("Passed the Exam!!");

//            }
//            else if (marks >= 75 && marks <= 100)
//            {
//                Console.WriteLine("Excellent!!!!");

//            }
//            else
//            {
//                Console.WriteLine("Imposible reach!");
//            }
//        }
//    }
//}






//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int retAge = 65;
//            Console.WriteLine("Enter your name: ");
//            String name = Console.ReadLine();
//            Console.WriteLine("Enter your age: ");
//            int age = Convert.ToInt32(Console.ReadLine());

//            int z = (retAge - age);
//            if (z > 0)
//            {
//                Console.WriteLine("Welcome " + name + ", you have " + z + " years left before your retirement.");

//            }
//            else if(z < 0) 
//            {
//                Console.WriteLine("Welcome " + name + ", you have 0 years left before your retirement.");
//            }

//        }
//    }
//}

















//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int x = 16;
//            int y = 12;
//            int max = x >= y ? x : y;
//            Console.WriteLine("Max of {0}, {1} is : {2}", x, y, max);
//        }
//    }
//}









//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int a = 16;
//            Console.WriteLine("Original a :  {0} ", a);
//            a += 16;  //a=a+16
//            Console.WriteLine("a +=16 :  {0} ", a); //32
//            a = 16;
//            a -= 8;
//            Console.WriteLine("a -=8 :  {0} ", a); //8
//            a = 16;
//            a /= 8;
//            Console.WriteLine("a /=8 :  {0} ", a); //2
//            a = 16;
//            a *= 4;
//            Console.WriteLine("a *=4 :  {0} ", a); //64
//            a = 16;
//            a %= 3;
//            Console.WriteLine("a %=3 :  {0} ", a); //1
//            a = 16;
//            a <<= 2; //a =a<<2
//            Console.WriteLine("a <<=2 :  {0} ", a); //64
//            a = 16;
//            a >>= 2; //a =a>>2
//            Console.WriteLine("a >>=2 :  {0} ", a); //4
//            a = 16;
//            a |= 2; //a =a|2
//            Console.WriteLine("a |=2 :  {0} ", a); //18
//            a = 16;
//            a &= 19; //a =a & 19
//            Console.WriteLine("a &=19 :  {0} ", a); //16
//            a = 16;
//            a ^= 2; //a =a^2
//            Console.WriteLine("a ^=2 :  {0} ", a); //18
//        }
//    }
//}










//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            Console.WriteLine("2147483647 << 1 : " + (2147483647 << 1));
//            //-ve value as this is the largest +ve value, when shifted 
//            //will make the last sign bit to be 1
//            Console.WriteLine("10<<2 : " + (10 << 2)); // 40
//            Console.WriteLine("10<<1 : " + (10 << 1));  //20
//            Console.WriteLine("16>>2 : " + (16 >> 2)); //4
//            Console.WriteLine("16>>1 : " + (16 >> 1)); //8

//        }
//    }
//}







//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int a = 10;
//            int b = 5;
//            Console.WriteLine("T && T : 10>5 && 10>=5 :  " + (10 > 5 && 10 >= 5));
//            Console.WriteLine("T && F : 10>5 && 10<5 :  " + (10 > 5 && 10 < 5));
//            Console.WriteLine("F && T : 10<=5 && 10>=5 :  " + (10 <= 5 && 10 >= 5));
//            Console.WriteLine("F && F : 10<5 && 10<=5 :  " + (10 < 5 && 10 <= 5));
//            Console.WriteLine("T || T : 10>5 || 10>=5 :  " + (10 > 5 || 10 >= 5));
//            Console.WriteLine("T || F : 10>5 || 10<5 :  " + (10 > 5 || 10 < 5));
//            Console.WriteLine("F || T : 10<=5 || 10>=5 :  " + (10 <= 5 || 10 >= 5));
//            Console.WriteLine("F || F : 10<5 || 10<=5 :  " + (10 < 5 || 10 <= 5));
//            Console.WriteLine("!T : !(10>5) :  {0}\n!F : !(10<5) : {1} ", !(10 > 5), !(10 < 5));

//        }
//    }
//}









//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int a = 10;
//            int b = 5;
//            bool res = a > b;
//            Console.WriteLine("Here a={4},b={5}\na>b : {0} \n a<b : {1}\n a<=b : {2}\n a>=b : {3}", res,
//                (a < b), (a <= b), (a >= b), a, b);
//            Console.WriteLine("a==b: {0} \n a!=b : {1} ", (a == b), (a != b));
//        }
//    }
//}
///*
//Here a =10,b=5
//a>b : True
// a<b : False
// a<=b : False
// a>=b : True
//a==b: False
// a!=b : True
//*/








//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            Console.WriteLine("Bitwise Operations: ");
//            Console.WriteLine("4 | 5 = " + (4 | 5) + " \n4 & 5 = " + (4 & 5)); //5 .. 4
//            Console.WriteLine("Not 4 = " + (~4));  //-5
//            Console.WriteLine("4 ^ 5 = " + (4 ^ 5)); //1

//        }
//    }
//}














//////Arithmetic Operators:
//using System;
//using System.ComponentModel;
//using System.Reflection;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int x = 10, y = 20, z = 0, d = 3;
//            int res = x + y;
//            Console.WriteLine("Addition Operator  : {0} + {1} = {2}", x, y, res);
//            res = x - y;
//            Console.WriteLine("Subtraction Operator  : {0} - {1} = {2}", x, y, res);
//            res = x * y;
//            Console.WriteLine("Multiplication Operator  : {0} * {1} = {2}", x, y, res);
//            res = y / x;
//            Console.WriteLine("Division Operator  : {0} / {1} = {2}", y, x, res);
//            res = z == 0 ? 0 : y / z;
//            Console.WriteLine("Division Operator (divide by zero breaks the program abruptly) : {0} / {1} = {2}", y, z, res);
//            res = x % d;
//            Console.WriteLine("Remainder Operator  : {0} % {1} = {2}", x, d, res);
//            res = x++; //post increment : res = x , x = x + 1
//            Console.WriteLine("Post Increment Operator  : (For x = 10) : x++ : x = {0} and res = {1}", x, res);
//            x = 10;
//            res = ++x; //pre increment : x = x + 1, res =x
//            Console.WriteLine("Pre Increment Operator  : (For x = 10) : ++x : x = {0} and res = {1}", x, res);
//            x = 10;
//            res = x--; //post decrement : res = x , x = x - 1
//            Console.WriteLine("Post Decrement Operator  : (For x = 10) : x-- : x = {0} and res = {1}", x, res);
//            x = 10;
//            res = --x; //pre decrement : x = x - 1, res =x
//            Console.WriteLine("Pre Decrement Operator  : (For x = 10) : --x : x = {0} and res = {1}", x, res);
//        }
//    }
//}















//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int x, y;
//            Console.WriteLine("Enter x: ");
//            x = Convert.ToInt32(Console.ReadLine());
//            Console.WriteLine("Enter y: ");
//            y = Int32.Parse(Console.ReadLine());
//            Console.WriteLine("Read values: x :" + x + ", y : " + y);
//            Console.WriteLine("Program ends!!");
//        }
//    }
//}













//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            Console.WriteLine("Enter your name:");
//            string name = Console.ReadLine();
//            Console.WriteLine("Entered name: " + name);
//            Console.WriteLine("Enter your Grade:");
//            char grade = Convert.ToChar(Console.Read());
//            Console.WriteLine("Entered grade: " + grade);

//            // ReadLine : reads till we pree Enter key
//            //ReadKey : reads one key press do not wait for delimiter like space, enterkey etc.
//            //Read : reads the ASCII value of the key press, it waits for the delimiter.
//            Console.WriteLine("Press any Key to continue..");
//            Console.ReadKey();
//            Console.WriteLine("Press Enter key to continue..");
//            Console.ReadLine();
//            Console.WriteLine("Enter a value, then press Enter key to continue..");
//            Console.Read();

//            Console.WriteLine("Program ends!!");
//        }
//    }
//}










//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int[] arr1 = { 1, 2, 3, 4 }; //array has length 4 elements, and index are 0 to 3
//            arr1[2] = 70;
//            Console.WriteLine("The elements  are: " + arr1[0] + ", " + arr1[1] + ", " + arr1[2] + ", " + arr1[3]);
//            Console.WriteLine("Printing the array as a string: " + arr1);
//            Console.WriteLine("Length of the array : " + arr1.Length);
//            int[] arr2 = new int[5];
//            int[] arr3 = new int[4] { 1, 2, 3, 4 };
//            int[] arr4 = new int[] { 1, 2, 3, 4 };
//        }
//    }
//}











//Pointers: Pointers are considered unsafe for high level languages.
//So pointers are coded inside unsafe block in C#.
//Any unsafe block cannot exist in a safe project. 
//So declare the project to be unsafe.


//using System;

//namespace PointerUnsafePrj
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            int x = 10;
//            unsafe
//            {
//                int* p = &x;
//                int a = (int)p;
//                Console.WriteLine((*p) + " has address as : " + a);
//            }

//        }
//    }
//}








//using System;

//namespace Prj1Day1Con
//{
//    enum Color : byte
//    {
//        Red = 1,
//        Green = 2,
//        Blue = 4,
//        Violet = 5,
//        BlueViolet = Blue | Violet,
//        Black = 0,
//        White = Red | Green | Blue
//    }

//    class Program
//    {
//        enum Month { Jan = 1, Feb, Mar, Apr, May, Jun, Jly, Aug, Sep, Oct, Nov, Dec };

//        static void Main()
//        {
//            Month first = Month.Jan;
//            Month second = (Month)2;
//            Month last = first + 11;
//            int march = (int)Month.Mar;
//            Console.WriteLine("First Month : " + first + " has Month number : " + (int)first);
//            Console.WriteLine("Last Month : " + last + " has Month number : " + (int)last);
//            Color c = Color.White;
//            System.Console.WriteLine(c);   // White
//            System.Console.WriteLine((int)c);// 7
//            Color c2 = Color.BlueViolet;
//            System.Console.WriteLine(c2);   // BlueViolet
//            System.Console.WriteLine((int)c2);// 5
//        }
//    }
//}













//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        enum Month { Jan = 1, Feb, Mar, Apr, May, Jun, Jly, Aug, Sep, Oct, Nov, Dec };

//        static void Main()
//        {
//            Month first = Month.Jan;
//            Month second = (Month)2;
//            Month last = first + 11;
//            int march = (int)Month.Mar;
//            Console.WriteLine("First Month : " + first + " has Month number : " + (int)first);
//            Console.WriteLine("Last Month : " + last + " has Month number : " + (int)last);





//        }
//    }
//}














//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            const int i = 10;
//            const int l = 20;
//            int j = 10;
//            int k = 20;
//            const int a = i + l;  //j + k;

//            Console.WriteLine("A const cannot be re-assigned");
//            Console.WriteLine("A const cannot be assigned to non const variables operating on values");
//            Console.WriteLine("A const can be assigned to const variables defined priorly");





//        }
//    }
//}














//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {

//            char c1 = '\n';
//            char c2 = '\t';
//            char c3 = '\a';
//            char c4 = '\u0144';
//            char c5 = '\'';
//            char c6 = '\"';
//            char c7 = '\\';
//            Console.WriteLine("There is a new line " + c1 + "between us! ");
//            Console.WriteLine("There is a tab space " + c2 + "between us! ");
//            Console.WriteLine("This is a beep sound " + c3);
//            Console.WriteLine("There is a unicode char  " + c4 + "between us! ");
//            Console.WriteLine("This text is under single quotes " + c5 + "Text!" + c5 + ". That's it!");
//            Console.WriteLine("This text is under double quotes " + c6 + "Text!" + c6 + ". That's it!");
//            Console.WriteLine("This text is has a slash printed out " + c7 + ". That's it!");



//        }
//    }
//}



///*
//There is a new line
//between us!
//There is a tab space    between us!
//This is a beep sound
//There is a unicode char  nbetween us!
//This text is under single quotes 'Text!'. That's it!
//This text is under double quotes "Text!". That's it!
//This text is has a slash printed out \. That's it!
//*/









//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            byte b = 127;
//            Console.WriteLine("Wrapper of byte: " + b.GetType());

//            short i = 127;
//            Console.WriteLine("Wrapper of short: " + i.GetType());

//            bool t = true;
//            Console.WriteLine("Wrapper of bool: " + t.GetType());

//            int x = 10;
//            Console.WriteLine("Wrapper of int: " + x.GetType());

//            long y = 100l;
//            Console.WriteLine("Wrapper of long: " + y.GetType());

//            uint ux = 100;
//            Console.WriteLine("Wrapper of uint: " + ux.GetType());

//            char c = 'A';
//            Console.WriteLine("Wrapper of char: " + c.GetType());

//            decimal d = (decimal)3.4;
//            Console.WriteLine("Wrapper of decimal: " + d.GetType());


//            float f = (float)3.4;
//            Console.WriteLine("Wrapper of float: " + f.GetType());

//            double dd = 3.4;
//            Console.WriteLine("Wrapper of double: " + dd.GetType());




//        }
//    }
//}

///*
//Wrapper of byte: System.Byte
//Wrapper of short: System.Int16
//Wrapper of bool: System.Boolean
//Wrapper of int: System.Int32
//Wrapper of long: System.Int64
//Wrapper of uint: System.UInt32
//Wrapper of char: System.Char
//Wrapper of decimal: System.Decimal
//Wrapper of float: System.Single
//Wrapper of double: System.Double
//*/













//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int x = 10;
//            int y = 20;
//            int z = x + y;
//            //x = 90;
//            Console.WriteLine("The sum of " + x + " + " + y + " = " + z);
//            z = x * y;
//            Console.WriteLine("The product of " + x + " * " + y + " = " + z);

//        }
//    }
//}










//using System;

//namespace Prj1Day1Con
//{
//    class Program
//    {
//        static void Main()
//        {
//            int x = 10;
//            int y = 20;
//            int z = x + y;

//            Console.WriteLine("The sum of " + x + " + " + y + " = " + z);

//        }
//    }
//}