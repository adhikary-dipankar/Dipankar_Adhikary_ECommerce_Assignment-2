﻿




using System;
using System.Linq;
namespace Prj1Day19Con
{
    class program
    { 

        static void Main(string[] args)
        {
            string[] flowers = { "dahlia", "rose", "lotus", "lily", "hibiscus", "daffodil" };
            var flrs = flowers.Where(f => f.StartsWith("d"));
            foreach (string g in flrs)
            {
                Console.WriteLine(g);
            }

        }

    }
}














//using System;
//using System.Linq;
//namespace Prj1Day19Con
//{
//    class program
//    {
//        delegate int Producer();
//        delegate void Consumer(int a);

//        static void Main(string[] args)
//        {
//            Producer p = () => 120;
//            Console.WriteLine(p());
//            Consumer c = x => Console.WriteLine(x*x);
//            c(23);



//        }

//    }
//}











//using System;
//using System.Linq;
//namespace Prj1Day19Con
//{
//    class program
//    {
//        delegate int Cube(int c);
//        delegate int Opt(int a,int b);

//        static void Main(string[] args)
//        {
//            Cube myc = x => x*x*x;
//            Console.WriteLine(myc(3));
//            Console.WriteLine(myc(5));

//            Opt add = (a,b) => a + b;
//            Console.WriteLine(add(12,98));
//            Opt sub = (a,b) => a>b? a - b:b-a;
//            Console.WriteLine(sub(12,23));


//        }

//    }
//}










//using System;
//using System.Linq;

//namespace Prj1Day19Col
//{


//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string poem = @"What is this life if, full of care,
//                We have, no time to stand and stare.
//                No time to stand, beneath the boughs
//                And stare as long as sheep or cows.
//                No time to see, when woods we pass,
//                Where, squirrels hide their nuts in grass.";
//            var matchQuery = from c in poem where c == 'd' select c;
//            int i = 0;
//            //foreach (char c in matchQuery)
//            //{
//            //    i++;
//            //}
//            Console.WriteLine("The number of , is: " + matchQuery.ToArray().Length);
//            //Console.WriteLine(i);   //


//        }

//    }
//}







//using System;
//using System.Linq;

//namespace Prj1Day19Col
//{


//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string[] flowers =
//                { "dahlia", "rose", "lotus", "daisy", "lily", "hibiscus", "daffodil" , "dandelions"};

//            var fQuery =
//            from flower in flowers
//            where (flower.StartsWith("d"))
//            select flower;
//            foreach (string flr in fQuery)
//            {
//                Console.WriteLine(flr);
//            }




//        }

//    }
//}














// De-serialization


//using System;
//using System.IO;
//using System.Text;
//using System.Runtime.Serialization.Formatters.Binary;

//namespace Prj1Day19Col
//{

//    [Serializable]
//    class Student
//    {
//        internal int rollno;
//        internal string name;
//        public Student(int rollno, string name)
//        {
//            this.rollno = rollno;
//            this.name = name;
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            FileStream stream = new FileStream("C:\\Dipankar\\sss.txt", FileMode.OpenOrCreate);
//            BinaryFormatter formatter = new BinaryFormatter();
//            Student s = (Student)formatter.Deserialize(stream);
//            Console.WriteLine("Name: " + s.name);
//            Console.WriteLine("Rollno: " + s.rollno);

//            stream.Close();


//        }

//    }
//}











// Serialization

//using System;
//using System.IO;
//using System.Text;
//using System.Runtime.Serialization.Formatters.Binary;

//namespace Prj1Day19Col
//{

//    [Serializable]
//    class Student
//    {
//        int rollno;
//        string name;
//        public Student(int rollno, string name)
//        {
//            this.rollno = rollno;
//            this.name = name;
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            FileStream stream = new FileStream("C:\\Dipankar\\sss.txt", FileMode.OpenOrCreate);
//            BinaryFormatter formatter = new BinaryFormatter();
//            Student s = new Student(101, "Dipankar");
//            formatter.Serialize(stream, s);
//            stream.Close();


//        }

//    }
//}










//using System;
//using System.Collections.Generic;
//using System.IO;

//namespace Prj1day19Col
//{
//    class Emp
//    {
//        public int Id { get; set; }
//        public string Name { get; set; }

//        public Emp(int id, string name)
//        {
//            Id = id;
//            Name = name;
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {

//            List<Emp> E = new List<Emp>
//        {
//            new Emp(1, "A"),
//            new Emp(2, "B"),
//            new Emp(3, "C"),
//            new Emp(4, "D"),
//            new Emp(5, "E"),
//            new Emp(6, "F"),
//            new Emp(7, "G"),
//            new Emp(8, "H"),
//            new Emp(9, "I"),
//            new Emp(10, "J")
//        };

//            Console.Write("Enter your employee ID (Id range 1 to 10): ");
//            if (int.TryParse(Console.ReadLine(), out int empID))
//            {
//                Emp employee = E.Find(emp => emp.Id == empID);
//                if (employee != null)
//                {
//                    DateTime DT = DateTime.Now;

//                    string logMessage = $"Emp with ID: {employee.Id} having name {employee.Name} has logged in at {DT}";


//                    string folderPath = "C:\\Dipankar";
//                    string filePath = Path.Combine(folderPath, "LoginDetails.txt");

//                    try
//                    {

//                        Directory.CreateDirectory(folderPath);


//                        File.AppendAllText(filePath, logMessage + Environment.NewLine);

//                        Console.WriteLine("Login details have been logged successfully.");
//                    }
//                    catch (Exception ex)
//                    {
//                        Console.WriteLine($"Error writing to the file: {ex.Message}");
//                    }
//                }
//                else
//                {
//                    Console.WriteLine("Employee not found with the provided ID.");
//                }
//            }
//            else
//            {
//                Console.WriteLine("Invalid employee ID.");
//            }
//        }
//    }
//}












//using System;
//using System.IO;
//using System.Text.RegularExpressions;
//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {

//            if (args.Length != 1)  // puting in cmd line  C:\\Dipankar\\second.cs 
//            {
//                Console.WriteLine("Usage: CheckFile for filename.cs ");
//                return;
//            }

//            string inputFileName = args[0];

//            if (!inputFileName.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
//            {
//                Console.WriteLine("Error in file checking: The file is not a C# file with extention .cs).");
//                return;
//            }

//            string outputFileName;


//            string fileContent;
//            try
//            {
//                fileContent = File.ReadAllText(inputFileName);
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine($"Error reading the file: {ex.Message}");
//                return;
//            }

//           
//            if (Regex.IsMatch(fileContent, @"\bMain\s*\(\s*string\[\]\s*args\s*\)|\bMain\s*\(\s*\)", RegexOptions.Multiline))
//            {
//                
//                outputFileName = Path.ChangeExtension(inputFileName, "exe");

//                try
//                {
//                    File.WriteAllText(outputFileName, fileContent);
//                    Console.WriteLine("Compiled successfully.");
//                }
//                catch (Exception ex)
//                {
//                    Console.WriteLine($"Error creating the executable file: {ex.Message}");
//                }
//            }
//            else
//            {

//                outputFileName = Path.ChangeExtension(inputFileName, "mydll");

//                try
//                {
//                    File.WriteAllText(outputFileName, fileContent);
//                    Console.WriteLine("Compiled successfully.");
//                }
//                catch (Exception ex)
//                {
//                    Console.WriteLine($"Error creating the mydll file: {ex.Message}");
//                }
//            }


//            try
//            {
//                File.Copy(inputFileName, outputFileName, true);
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine($"Error copying file content: {ex.Message}");
//            }
//        }
//    }
//}













//using System;
//using System.ComponentModel.Design;
//using System.IO;
//using System.Text;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            while (true)
//            {

//                Console.WriteLine("Main Menu:\n1. Using File\n2. Using FileStream" +
//                    "\n3. Using StreamReader and StreamWriter\n4. Exit");

//                if (int.TryParse(Console.ReadLine(), out int ch))
//                {
//                    switch (ch)
//                    {
//                        case 1:
//                            FileMenu();
//                            break;
//                        case 2:
//                            FileStreamMenu();
//                            break;
//                        case 3:
//                            StreamReaderStreamWriterMenu();
//                            break;
//                        case 4:
//                            return;
//                        default:
//                            Console.WriteLine("Invalid choice: Please enter a valid input.");
//                            break;
//                    }
//                }
//                else
//                {
//                    Console.WriteLine("Invalid input: Please enter a valid option input.");
//                }
//            }
//        }

//        static void FileMenu()
//        {
//            string fileName = "MyFile.txt";

//            while (true)
//            {
//                Console.WriteLine("\nFile Menu:\n1. Write to File\n2. Read from the File\n3. Go to Main Menu");

//                if (int.TryParse(Console.ReadLine(), out int ch))
//                {
//                    switch (ch)
//                    {
//                        case 1:
//                            WriteToFile(fileName);
//                            break;
//                        case 2:
//                            ReadFromFile(fileName);
//                            break;
//                        case 3:
//                            return;
//                        default:
//                            Console.WriteLine("Invalid choice: Please enter a valid  input.");
//                            break;
//                    }
//                }
//                else
//                {
//                    Console.WriteLine("Invalid inpu: Please enter a valid input.");
//                }
//            }
//        }

//        static void WriteToFile(string fileName)
//        {
//            Console.WriteLine("\nEnter text: or close the write mood enter d: ");
//            string ui;

//            using (StreamWriter writer = new StreamWriter(fileName))
//            {
//                while (true)
//                {
//                    ui = Console.ReadLine();
//                    if (ui.ToLower() == "d")
//                        break;

//                    writer.WriteLine(ui);
//                }
//            }
//        }

//        static void ReadFromFile(string fileName)
//        {
//            if (!File.Exists(fileName))
//            {
//                Console.WriteLine("The file does not exist. Please write to the file first.");
//                return;
//            }

//            Console.WriteLine("\n Read the File's content:");

//            using (StreamReader reader = new StreamReader(fileName))
//            {
//                string line;
//                while ((line = reader.ReadLine()) != null)
//                {
//                    Console.WriteLine(line);
//                }
//            }
//        }

//        static void FileStreamMenu()
//        {

//            Console.WriteLine("File Stream Menu (Not implemented yet).");
//        }

//        static void StreamReaderStreamWriterMenu()
//        {
//            string fileName = "MyFile.txt";
//            string ui;
//            int wc = 0;

//            Console.WriteLine("Enter content or close enter d: ");

//            using (StreamWriter writer = new StreamWriter(fileName))
//            {
//                while (true)
//                {
//                    ui = Console.ReadLine();
//                    if (ui.ToLower() == "d")
//                        break;

//                    writer.WriteLine(ui);
//                }
//            }
//            using (StreamReader reader = new StreamReader(fileName))
//            {
//                string fileContent = reader.ReadToEnd();
//                string[] words = fileContent.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
//                wc = words.Length;
//            }

//            Console.WriteLine($"\nNumber of words in the file: {wc}\n");


//            Console.WriteLine("File Content:");
//            using (StreamReader reader = new StreamReader(fileName))
//            {
//                string line;
//                while ((line = reader.ReadLine()) != null)
//                {
//                    Console.WriteLine(line);
//                }
//            }
//        }
//    }
//}

























//using System;
//using System.IO;
//using System.Text;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {

//            StreamReader sr = new StreamReader("C://Dipankar//file1.txt");
//            Console.WriteLine("Content of the File");
//            sr.BaseStream.Seek(0, SeekOrigin.Begin);
//            string str = sr.ReadLine();
//            while (str != null)
//            {
//                Console.WriteLine(str);
//                str = sr.ReadLine();
//            }

//            sr.Close();
//        }

//    }
//}













//using System;
//using System.IO;
//using System.Text;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {

//            StreamWriter sw = new StreamWriter("C://Dipankar//file1.txt");
//            Console.WriteLine("Enter the Text that you want to write on File");
//            string str = Console.ReadLine();
//            sw.WriteLine(str);
//            sw.Flush();
//            sw.Close();



//        }

//    }
//}










//Write()
//Write data to the stream. It has different overloads for different data types to write in stream.
//WriteLine()
//It is same as Write() but it adds the newline character at the end of the data.

//StreamReader Class
//The StreamReader class implements TextReader for reading character from the stream in a particular format.
//METHOD
//DESCRIPTION
//Close()
//Closes the current StreamReader object and stream associate with it.
//Peek()
//Returns the next available character but does not consume it.
//Read()
//Reads the next character in input stream and increment characters position by one in the stream
//ReadLine()
//Reads a line from the input stream and return the data in form of string
//Seek()
//It is use to read / write at the specific location from a file















//using System;
//using System.IO;
//using System.Text;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {


//            File.WriteAllText("C:\\Dipankar\\HelloWorld-copy.txt", File.ReadAllText("C:\\Dipankar\\HelloWorld.txt"));



//        }

//    }
//}


















//using System;
//using System.IO;
//using System.Text;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            FileStream fWrite = new FileStream(@"C:\Dipankar\Textfile.txt", FileMode.Create, FileAccess.Write, FileShare.None);
//            var text = "This is some text written to the textfile " + "named Textfile using FileStream class.";

//            byte[] writeArr = Encoding.UTF8.GetBytes(text);
//            fWrite.Write(writeArr, 0, text.Length);  
//            fWrite.Close();

//            FileStream fRead = new FileStream(@"C:\Dipankar\TextfileCopy.txt", FileMode.Create, FileAccess.Write, FileShare.None);
//            var r = File.Read(fWrite);
//            byte[] ar = Encoding.UTF8.GetBytes(r);
//            fRead.Write(ar,0,ar.Length);   
//            fRead.Close();


//        }

//    }
//}









//using System;
//using System.IO;


//namespace Prj1Day19Col
//{
//    class program
//    {

//        static void Main(string[] args)
//        {
//            string f = "C:\\Dipankar\\HelloWorld.txt";

//            while (true)
//            {
//                Console.WriteLine("Menu: ");
//                Console.WriteLine("1. Write to a file.");
//                Console.WriteLine("2. Append to a file.");
//                Console.WriteLine("3. Read from a file.");
//                Console.WriteLine("4. Exit.");

//                int ch;
//                if (int.TryParse(Console.ReadLine(), out ch))
//                {
//                    switch (ch)
//                    {
//                        case 1:
//                            Console.WriteLine("Enter your text to write: ");
//                            string s = Console.ReadLine();
//                            File.WriteAllText(f, s); break;
//                        case 2:
//                            Console.WriteLine("Enter your text to append: ");
//                            string ap = Console.ReadLine();
//                            File.AppendAllText(f, ap);
//                            break;


//                        case 3:
//                            string r = File.ReadAllText(f);
//                            Console.WriteLine("Reading from the file: ");
//                            Console.Write(r); break;
//                        case 4:
//                            Console.WriteLine("Exit from the file HelloWorld.txr "); break;
//                        default:
//                            Console.WriteLine("Invaild Choich entered.");

//                            break;
//                    }
//                }
//                break;
//            }
//        }
//    }
//}
















//using System;
//using System.IO;
//using System.Text;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            FileStream fWrite = new FileStream(@"C:\Dipankar\Textfile.txt", FileMode.Create, FileAccess.Write, FileShare.None);
//            var text = "This is some text written to the textfile " + "named Textfile using FileStream class.";
//            // Store the text in a byte array with  UTF8 encoding (8-bit Unicode  Transformation Format) 
//            byte[] writeArr = Encoding.UTF8.GetBytes(text);
//            fWrite.Write(writeArr, 0, text.Length);   //Write to file
//            fWrite.Close();
//            FileStream fRead = new FileStream(@"C:\Dipankar\Textfile.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
//            byte[] readArr = new byte[text.Length];
//            int count;
//            while ((count = fRead.Read(readArr, 0, readArr.Length)) > 0)
//            {
//                Console.WriteLine(Encoding.UTF8.GetString(readArr, 0, count));   //Read from file
//            }
//            fRead.Close();


//        }

//    }
//}











//File IO classes:
//BinaryReader: Reads primitive data from a binary stream.
//BinaryWriter : Writes primitive data in binary format.
//BufferedStream : A temporary storage for a stream of bytes.
//Directory : Helps in manipulating a directory structure.
//DirectoryInfo : Used for performing operations on directories.
//DriveInfo : Provides information for the drives. 
//File : Helps in manipulating files.
//FileInfo : Used for performing operations on files.
//FileStream : Used to read from and write to any location in a file.
//MemoryStream : Used for random access to streamed data stored in memory.
//Path : Performs operations on path information.
//StreamReader : Used for reading characters from a byte stream.
//StreamWriter : Is used for writing characters to a stream.
//StringReader : Is used for reading from a string buffer.
//StringWriter : Is used for writing into a string buffer.









//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Name
//    {
//        public string name;
//        public Name(string nm) { this.name = nm; }
//        public override int GetHashCode()
//        {
//            return (name.ToCharArray())[0];
//        }
//        public override bool Equals(object obj)
//        {
//            Name s = (Name)obj;
//            return name.Equals(s.name);
//        }
//        public override string ToString()
//        {
//            return name;
//        }
//    }


//    class Program
//    {
//        static void Main(string[] args)
//        {

//            LinkedList<string> strs = new LinkedList<string>();
//            strs.AddFirst("A");
//            strs.AddFirst("C");
//            strs.AddLast("D");
//            foreach (string s in strs)
//            {
//                Console.WriteLine(s);//C A D
//            }


//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine("\n" + s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}










//using System;
//using System.Collections.Generic;


//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Dictionary<string, List<string>> D = new Dictionary<string, List<string>>();


//            AddWordMean(D, "Lazy", new List<string> { "1. The situation when one is makeup his/her mind don't anythings and just lay down.", "2. Type of sloth." ,"3. Eat lots of foods."});
//            AddWordMean(D, "Book", new List<string> { "1. A written or printed work.", "2. To reserve Data","3. Documentation of history." });
//            AddWordMean(D, "Developer", new List<string> { "1. Who can code restlessly in all time.", "2. Sleep only few hours per day or week.","3. Can't developed a house physicall." });
//            AddWordMean(D, "Money", new List<string> { "1. It is one of the main essential object in our livlihood.",
//            "2. Always brings happiness.","3. Also it can fly as a rocket from your pocket."});


//            Console.Write("\nEnter a word to search( lazy,book,developer,money): ");
//            string searchW = Console.ReadLine().ToLower();

//            if (D.ContainsKey(searchW))
//            {
//                List<string> meanings = D[searchW];
//                Console.WriteLine($"\nMeanings of '{searchW}':\n");
//                foreach (var m in meanings)
//                {
//                    Console.WriteLine(m);
//                }
//            }
//            else
//            {
//                Console.WriteLine($"\n'{searchW}' not found in the dictionary.");
//            }
//        }
//        static void AddWordMean(Dictionary<string, List<string>> d, string w, List<string> meanings)
//        {
//            w = w.ToLower();
//            d[w] = meanings;
//        }
//    }

//}







//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Name
//    {
//        public string name;
//        public Name(string nm) { this.name = nm; }
//        public override int GetHashCode()
//        {
//            return (name.ToCharArray())[0];
//        }
//        public override bool Equals(object obj)
//        {
//            Name s = (Name)obj;
//            return name.Equals(s.name);
//        }
//        public override string ToString()
//        {
//            return name;
//        }
//    }


//    class Program
//    {
//        static void Main(string[] args)
//        {
//            SortedList<int, string> My_dict1 = new SortedList<int, string>();
//            My_dict1.Add(1223, "Welcome");
//            My_dict1.Add(1124, "to");
//            My_dict1.Add(1123, "C# programming");
//            foreach (KeyValuePair<int, string> ele1 in My_dict1)
//            {
//                Console.WriteLine("{0} and {1}", ele1.Key, ele1.Value);
//            }
//            Console.WriteLine();
//            Dictionary<string, string> My_dict2 = new Dictionary<string, string>(){
//                                {"a.1", "Dog"}, {"a.2", "Cat"}, {"a.3", "Rat"} };
//            foreach (KeyValuePair<string, string> ele2 in My_dict2)
//            {
//                Console.WriteLine("{0} and {1}", ele2.Key, ele2.Value);
//            }

//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine("\n" + s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}








//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Name
//    {
//        public string name;
//        public Name(string nm) { this.name = nm; }
//        public override int GetHashCode()
//        {
//            return (name.ToCharArray())[0];
//        }
//        public override bool Equals(object obj)
//        {
//            Name s = (Name)obj;
//            return name.Equals(s.name);
//        }
//        public override string ToString()
//        {
//            return name;
//        }
//    }


//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Dictionary<int, string> My_dict1 = new Dictionary<int, string>();
//            My_dict1.Add(1123, "Welcome");
//            My_dict1.Add(1124, "to");
//            My_dict1.Add(1125, "C# programming");
//            foreach (KeyValuePair<int, string> ele1 in My_dict1)
//            {
//                Console.WriteLine("{0} and {1}", ele1.Key, ele1.Value);
//            }
//            Console.WriteLine();
//            Dictionary<string, string> My_dict2 = new Dictionary<string, string>(){
//                                {"a.1", "Dog"}, {"a.2", "Cat"}, {"a.3", "Rat"} };
//            foreach (KeyValuePair<string, string> ele2 in My_dict2)
//            {
//                Console.WriteLine("{0} and {1}", ele2.Key, ele2.Value);
//            }

//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine("\n" + s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}










//Prepare a hashtable with the Emp class, making the id (int) 
//of the emp as the key and the emp object its value.

//At least 5 records should be entered.

//Enter a key (user input) and search for the emp object according to the key in the hashtable.
//Emp(id, name, sal)



//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Employee
//    {
//        public int Id { get; set; }
//        public string Name { get; set; }
//        public Double Sal { get; set; }

//        public Employee() { }
//        public Employee(int id, string name, double sal)
//        {
//            Id = id;
//            Name = name;
//            Sal = sal;
//        }
//    }


//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Hashtable nlist = new Hashtable();
//            nlist.Add(101, new Employee(101, "Monkey", 123.00));
//            nlist.Add(102,new Employee(102, "Man",233.0));
//            nlist.Add(103,new Employee(103, "Snake",984.00));
//            nlist.Add(104, new Employee(104, "Dog",84785.00));
//            nlist.Add(105, new Employee(105, "Cat",69867.00));
//            nlist.Add(106,new Employee(106, "Fish",340.00));
//            nlist.Add(107,new Employee(107, "Ccodile",83763.00));


//            Console.WriteLine("Enter the key in givcen range(101 to 107): ");
//            int k = Convert.ToInt32(Console.ReadLine());

//            if (nlist.ContainsKey(k))
//            {
//                Employee e = (Employee)nlist[k];
//                Console.WriteLine($"Employee Id: {e.Id}, Name: {e.Name} and Salary: {e.Sal}");
//            }
//            else
//            {
//                Console.WriteLine("Employee not Found by the Entered ID.");
//            }


//        }   
//    }
//}















//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Name
//    {
//        public string name;
//        public Name(string nm) { this.name = nm; }
//        public override int GetHashCode()
//        {
//            return (name.ToCharArray())[0];
//        }
//        public override bool Equals(object obj)
//        {
//            Name s = (Name)obj;
//            return name.Equals(s.name);
//        }
//        public override string ToString()
//        {
//            return name;
//        }
//    }


//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Hashtable nlist = new Hashtable();
//            nlist.Add(new Name("Trisha"), "V");
//            nlist.Add(new Name("Nisha"), "VI");
//            nlist.Add(new Name("Nimisha"), "X");
//            nlist.Add(new Name("Varsha"), "IV");
//            nlist.Add(new Name("Treena"), "II");
//            //nlist.Add(new Name("Nimisha"), "XI");
//            Console.WriteLine(nlist[new Name("Nimisha")]);
//            Console.WriteLine("\nforeach via DictionaryEntry(Key,Value):");
//            foreach (DictionaryEntry d in nlist)
//            {
//                Console.WriteLine(d.Key + " has the value as : " + d.Value);
//            }
//            Console.WriteLine("\nforeach via Set of Keys:");

//            foreach (Name l in nlist.Keys)
//            {
//                Console.WriteLine(l + " has the value as : " + nlist[l]);
//            }
//            foreach (String l in nlist.Values)
//            {
//                Console.WriteLine(l + " is the value.");
//            }


//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine("\n" + s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}









//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Emp : IComparable<Emp>
//    {
//        public int id { get; set; }
//        public string name { get; set; }
//        public int sal { get; set; }

//        public Emp() { }
//        public Emp(int id, string name, int sal)
//        {
//            this.id = id;
//            this.name = name;
//            this.sal = sal;
//        }

//        public int CompareTo(Emp other)
//        {
//            return this.sal == other.sal ? this.id - other.id : this.sal - other.sal;
//        }

//        public override string ToString()
//        {
//            return "Emp: Id: " + id + " Name : " + name + " Salary : " + sal;
//        }

//    }

//    class NameComparer : IComparer<Emp>
//    {
//        public int Compare(Emp x, Emp y)
//        {
//            return x.name.CompareTo(y.name);
//        }
//    }
//    class IdComparer : IComparer<Emp>
//    {
//        public int Compare(Emp x, Emp y)
//        {
//            return x.id - y.id;
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Emp> emps = new List<Emp>() {
//                new Emp(101,"A1",100000),
//                new Emp(105,"C1",100000),
//                new Emp(103,"E1",200000),
//                new Emp(104,"B1",10000),
//                new Emp(102,"D1",177000),
//            };
//            print("The Original List: ", emps);
//            emps.Sort();
//            print("The Default Sorted List (Salary) : ", emps);
//            emps.Sort(new NameComparer());
//            print("The Sorted List (Name) : ", emps);
//            emps.Sort(new IdComparer());
//            print("The Sorted List (Id) : ", emps);
//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine("\n" + s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}









//using System;
//using System.Collections.Generic;
//using System.Linq;

//class Employee
//{
//    public string Name { get; set; }
//    public string Designation { get; set; }

//    public Employee(string name, string designation)
//    {
//        Name = name;
//        Designation = designation;
//    }


//    public override int GetHashCode()
//    {
//        return Name.GetHashCode() ^ Designation.GetHashCode();
//    }

//    public override bool Equals(object obj)
//    {
//        if (obj is Employee otherEmployee)
//        {
//            return Name == otherEmployee.Name && Designation == otherEmployee.Designation;
//        }
//        return false;
//    }
//}

//class Program
//{
//    static void Main(string[] args)
//    {
//        List<Employee> list1 = new List<Employee>
//        {
//            new Employee("A", "PM"),
//            new Employee("B", "PrjM"),
//            new Employee("C", "SP"),
//            new Employee("J", "SP"),
//            new Employee("W", "TL")
//        };

//        List<Employee> list2 = new List<Employee>
//        {
//            new Employee("A", "PM"), // duplicate value
//            new Employee("B", "PrjM"), // duplicate value
//            new Employee("F", "PM"),
//            new Employee("G", "TL"),
//            new Employee("T", "PrjM")
//        };

//        HashSet<Employee> mergedList = new HashSet<Employee>(list1.Concat(list2));

//        Console.WriteLine("Merged Employee List:");
//        foreach (var employee in mergedList)
//        {
//            Console.WriteLine($"Name: {employee.Name}, Designation: {employee.Designation}");
//        }
//    }
//}


















//using System;
//using System.Collections.Generic;


//class Employee
//{
//    public string Name { get; set; }
//    public string Designation { get; set; }

//    public Employee(string name, string designation)
//    {
//        Name = name;
//        Designation = designation;
//    }
//}

//class DesignationLists
//{
//    public List<Employee> PM { get; } = new List<Employee>();
//    public List<Employee> PrjM { get; } = new List<Employee>();
//    public List<Employee> TL { get; } = new List<Employee>();
//    public List<Employee> SP { get; } = new List<Employee>();
//    public List<Employee> JP { get; } = new List<Employee>();
//}

//class Program
//{
//    static void Main(string[] args)
//    {
//        DesignationLists d = new DesignationLists();

//        while (true)
//        {
//            Console.WriteLine("Menu:\n1. Add Employee\n2. Display List\n3. Exit");
//            int ch = int.Parse(Console.ReadLine());

//            switch (ch)
//            {
//                case 1:
//                    AddEmployee(d);
//                    break;
//                case 2:
//                    Display(d);
//                    break;
//                case 3:
//                    return;
//                default:
//                    Console.WriteLine("Invalid choice. Please choose a valid option.");
//                    break;
//            }
//        }
//    }

//    static void AddEmployee(DesignationLists d)
//    {
//        Console.WriteLine("Enter employee name: ");
//        string name = Console.ReadLine();

//        Console.WriteLine("Enter employee designation: 'PM', 'PrjM', 'TL', 'SP', 'JP' ");
//        string dg = (Console.ReadLine()).ToLower();

//        Employee employee = new Employee(name, dg);


//        switch (dg)
//        {
//            case "pm":
//                d.PM.Add(employee);
//                break;
//            case "prjm":
//                d.PrjM.Add(employee);
//                break;
//            case "tl":
//                d.TL.Add(employee);
//                break;
//            case "sp":
//                d.SP.Add(employee);
//                break;
//            case "jp":
//                d.JP.Add(employee);
//                break;
//            default:
//                Console.WriteLine("Invalid designation Enetred: Employee can not be added to the designation list.");
//                break;
//        }
//    }

//    static void Display(DesignationLists d)
//    {
//        Console.WriteLine("\nDisplay the Employee List Below:");
//        DisplayEmp("" +
//            "Program Managers:\n", d.PM);
//        DisplayEmp("Project Managers:\n", d.PrjM);
//        DisplayEmp("Team Leads:\n", d.TL);
//        DisplayEmp("Senior Programmers:\n", d.SP);
//        DisplayEmp("Junior Programmers:\n", d.JP);
//    }

//    static void DisplayEmp(string s, List<Employee> E)
//    {
//        Console.WriteLine(s);
//        foreach (var e in E)
//        {
//            Console.WriteLine($" Employee Name is: {e.Name}, and Designation is: {e.Designation}");
//            Console.WriteLine("\n");
//        }
//    }
//}













//using System;
//using System.Collections.Generic;
//public class StackExample
//{
//    public static void Main(string[] args)
//    {
//        Queue<string> names = new Queue<string>();  //push and pop 
//        names.Enqueue("Eric");  //push adds elements
//        names.Enqueue("Boo");
//        names.Enqueue("Alain");
//        names.Enqueue("Jeff");
//        foreach (string name in names)
//            Console.WriteLine(name);
//        //Peek returns the First element entered without deleting it
//        //Dequeue returns the First element entered after deleting it
//        Console.WriteLine("Peek First element: " + names.Peek());  //Eric
//        Console.WriteLine("Dequeing First Element: " + names.Dequeue());     //Eric
//        Console.WriteLine("After Dequeing, Peek First element: " + names.Peek());   //Boo
//        foreach (string name in names)
//            Console.WriteLine(name);
//        Console.ReadLine();
//    }
//}








//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Abc
//    {
//        public override int GetHashCode()
//        {
//            return 10;
//        }
//        public override bool Equals(object obj)
//        {
//            return true;
//        }

//    }
//    class Emp
//    {
//        string name;
//        int id;
//        public Emp() { }
//        public Emp(string name, int id)
//        {
//            this.name = name;
//            this.id = id;
//        }
//        public override string ToString()
//        {
//            return "Emp Name: " + name + " Id :  " + id;
//        }
//        public override bool Equals(object obj)
//        {
//            Emp e = (Emp)obj;
//            return this.name == e.name && this.id == e.id;
//        }
//        public override int GetHashCode()
//        {
//            return this.id;
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            SortedSet<string> l1 = new SortedSet<string>() { "AX", "P", "AXMA", "C", "AXMA", "AXMB", "B", "a" };
//            print("HashSet of string values: ", l1);
//            //HashSet<Emp> l2 = new HashSet<Emp>() {
//            //    new Emp("A",101),
//            //    new Emp("B",102),
//            //    new Emp("A",101),
//            //    new Emp("C",103)
//            //};
//            //print("HashSet of Emp values: ", l2);
//            Console.WriteLine();

//            //Abc abc= new Abc();
//            //Abc abc2 = new Abc();
//            //Console.WriteLine(abc); // abc.ToString() return the Object class name: Prj1Day19Col.Emp
//            //Console.WriteLine(abc2);
//            //Console.WriteLine(abc.GetHashCode());
//            //Console.WriteLine(abc2.GetHashCode());
//            //Console.WriteLine(abc.Equals(abc2));

//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine(s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}


//Natural Ordering : 
//Numerical: Int16, Int32, Double, Float, Byte, … : Ascending Order
//string : lexicographical ordering: dictionary type
//File paths: lexicographical ordering : according to path variation from the current location
//Location : lexicographical ordering of latitude and longitude
//Date and time: Chronological ordering : past comes before the future









//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Abc
//    {
//        public override int GetHashCode()
//        {
//            return 10;
//        }
//        public override bool Equals(object obj)
//        {
//            return true;
//        }

//    }
//    class Emp
//    {
//        string name;
//        int id;
//        public Emp() { }
//        public Emp(string name, int id)
//        {
//            this.name = name;
//            this.id = id;
//        }
//        public override string ToString()
//        {
//            return "Emp Name: " + name + " Id :  " + id;
//        }
//        public override bool Equals(object obj)
//        {
//            Emp e = (Emp)obj;
//            return this.name == e.name && this.id == e.id;
//        }
//        public override int GetHashCode()
//        {
//            return this.id;
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            HashSet<string> l1 = new HashSet<string>() { "A", "B", "A", "C" };
//            print("HashSet of string values: ", l1);
//            HashSet<Emp> l2 = new HashSet<Emp>() {
//                new Emp("A",101),
//                new Emp("B",102),
//                new Emp("A",101),
//                new Emp("C",103)
//            };
//            print("HashSet of Emp values: ", l2);
//            Console.WriteLine();

//            //Abc abc= new Abc();
//            //Abc abc2 = new Abc();
//            //Console.WriteLine(abc); // abc.ToString() return the Object class name: Prj1Day19Col.Emp
//            //Console.WriteLine(abc2);
//            //Console.WriteLine(abc.GetHashCode());
//            //Console.WriteLine(abc2.GetHashCode());
//            //Console.WriteLine(abc.Equals(abc2));

//        }

//        public static void print(string s, IEnumerable e)
//        {
//            Console.WriteLine(s);
//            foreach (object o in e)
//            {
//                Console.WriteLine(o);
//            }
//        }

//    }
//}






//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Emp
//    {
//        string name;
//        int id;
//        public Emp() { }
//        public Emp(string name, int id)
//        {
//            this.name = name;
//            this.id = id;
//        }
//        public override string ToString()
//        {
//            return "Emp Name: " + name + " Id :  " + id;
//        }
//        public override bool Equals(object obj)
//        {
//            Emp e = (Emp)obj;
//            return this.name == e.name && this.id == e.id;
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Emp> l2 = new List<Emp>(){
//                new Emp("John",101),
//                new Emp("Doe", 102)
//            };
//            //l2.Add(45); 
//            //runtime problem for Arraylist is now a compile time 
//            //problem for generic List
//            l2.Add(new Emp("Abc", 103));
//            foreach (Emp s in l2)
//            {
//                Console.WriteLine(s);
//            }
//            l2.Remove(new Emp("Abc", 103));
//            Console.WriteLine("\n\nPost removal: ");
//            foreach (Emp s in l2)
//            {
//                Console.WriteLine(s);
//            }
//            Console.WriteLine();
//        }

//    }
//}








//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Emp
//    {
//        string name;
//        int id;
//        public Emp() { }
//        public Emp(string name, int id)
//        {
//            this.name = name;
//            this.id = id;
//        }
//        public override string ToString()
//        {
//            return "Emp Name: " + name + " Id :  " + id;
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            List<Emp> l2 = new List<Emp>(){
//                new Emp("John",101),
//                new Emp("Doe", 102)
//            };

//            l2.Add(new Emp("Abc", 103));
//            foreach (Emp s in l2)
//            {
//                Console.WriteLine(s);
//            }


//        }

//    }
//}






//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            //ArrayList l1=new ArrayList();
//            //l1.Add("John");
//            //l1.Add("Doe");
//            //l1.Add(45);
//            //foreach(string  o in l1)
//            //{
//            //    Console.WriteLine(o);
//            //}

//            List<string> l2 = new List<string>();
//            l2.Add("John");
//            l2.Add("Doe");
//            //l2.Add(45); 
//            //runtime problem for Arraylist is now a compile time 
//            //problem for generic List
//            foreach (string s in l2)
//            {
//                Console.WriteLine(s);
//            }


//        }

//    }
//}









//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{
//    public class MinMaxFinder<T> where T : IComparable<T>
//    {
//        private T[] Ele;

//        public MinMaxFinder(T A, T B, T C)
//        {
//            if(!(A is IConvertible) || !(B is IConvertible)|| !(C is IConvertible))
//            {
//                throw new ArgumentException("All Elements must be numbers or  be converted into number.");
//            }
//            Ele = new T[] { A, B, C };
//        }

//        public T FindMin()
//        {
//            T min = Ele[0];
//            foreach (T element in Ele)
//            {
//                if (element.CompareTo(min) < 0)
//                {
//                    min = element;
//                }
//            }

//            return min;

//        }

//        public T FindMax()
//        {
//            T max = Ele[0];
//            foreach (T element in Ele)
//            {
//                if (element.CompareTo(max) > 0)
//                {
//                    max = element;
//                }
//            }

//            return max;
//        }
//    }


//    class Program
//    {
//        static void Main()
//        {
//            try
//            {

//                MinMaxFinder<int> intMinMaxFinder = new MinMaxFinder<int>(10, 5, 15);
//                int minInt = intMinMaxFinder.FindMin();
//                int maxInt = intMinMaxFinder.FindMax();

//                MinMaxFinder<double> doubleMinMaxFinder = new MinMaxFinder<double>(3.14, 1.0,3.4);
//                double minDouble = doubleMinMaxFinder.FindMin();
//                double maxDouble = doubleMinMaxFinder.FindMax();

//                Console.WriteLine($"The Min Int Element is : {minInt}, The Max Int Element is : {maxInt}");
//                Console.WriteLine($"The Min Double Element is : {minDouble}, The Max Double Element is : {maxDouble}");
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine("The Min-Max can not find due to input utherthan numbers: " + ex.Message);
//            }


//        }
//    }
//}












//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{
//    class Message<T>
//    {
//        //int x;
//        public T usrMsg { get; set; }

//        public Message() { }
//        public Message(T msg) { usrMsg = msg; }
//        public override string ToString()
//        {
//            return usrMsg.ToString();
//        }
//    }
//    class Images
//    {
//        public int Size;
//        public Images() { }
//        public Images(int si) { Size = si; }
//        public override string ToString()
//        {
//            return "This is an Image of size : " + Size;
//        }
//    }
//    class Vdo
//    {
//        public Vdo() { }
//        public Vdo(string q) { quality = q; }
//        public string quality { get; set; }
//        public override string ToString()
//        {
//            return "This is a Video file sent with quality : " + quality;
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Message<Images> slidesnapshot = new Message<Images>();
//            slidesnapshot.usrMsg = new Images(1000);
//            Console.WriteLine(slidesnapshot);
//            Message<Vdo> CSharpTutorial = new Message<Vdo>();
//            CSharpTutorial.usrMsg = new Vdo("HDD");
//            Console.WriteLine(CSharpTutorial);
//            Message<string> msg = new Message<string>();
//            msg.usrMsg = "This is a msg in group";
//            Console.WriteLine(msg);


//        }

//    }
//}







//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{
//    class emp
//    {
//        string name;
//        int id;

//        public emp(string name, int id)
//        {
//            this.name = name;
//            this.id = id;
//        }
//        public override string ToString()
//        {
//            return name;
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            ArrayList list = new ArrayList();
//            emp e = new emp("Nisha", 101);
//            list.Add("Shriya"); list.Add("Soham"); list.Add("Sujan");
//            list.Add("Sagar"); list.Add("Shirisha"); list.Add("Arkabrata");
//            list.Add("Jitendra"); list.Add("Tejas"); list.Add("Trapti");
//            list.Add(e); list.Add("Rishita"); list.Add("Krishna");
//            list.Add("Abir"); list.Add("Debanjan"); list.Add("Debjani");
//            list.Add("Shriya"); list.Add("Soham"); list.Add("Sujan");
//            list.Add("Sagar"); list.Add("Shirisha"); list.Add("Arkabrata");
//            list.Add("Jitendra"); list.Add("Tejas"); list.Add("Trapti");
//            list.Add("Shriya"); list.Add("Soham"); list.Add("Sujan");
//            list.Add("Sagar"); list.Add("Shirisha"); list.Add("Arkabrata");
//            list.Add("Jitendra"); list.Add("Tejas"); list.Add("Trapti");
//            list.Add("Shriya"); list.Add("Soham"); list.Add("Sujan");
//            list.Add("Sagar"); list.Add("Shirisha"); list.Add("Arkabrata");
//            list.Add("Jitendra"); list.Add("Tejas"); list.Add("Trapti");
//            list.Add("Divyani"); list.Add("Amisha");
//            Console.WriteLine("Count:{0}", list.Count);
//            Console.WriteLine("Capacity:{0}", list.Capacity);
//            PrintValues("\nArray list Values:", list);
//            Console.WriteLine("\nGetting element's index position:" + list.IndexOf(new emp("Nisha", 101)));
//            Console.WriteLine("\nGetting element's last index position:" + list.LastIndexOf("Arkabrata"));
//            //list.Sort();
//            //PrintValues("\n\nSorted Values:", list);

//            Console.WriteLine();
//        }
//        public static void PrintValues(string s, IEnumerable myList)
//        {
//            Console.WriteLine(s);
//            foreach (Object obj in myList)
//            {
//                //string str = (string)obj;
//                Console.Write(obj + "\t");
//            }
//        }
//    }
//}













//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            ArrayList list = new ArrayList();
//            list.Add("Shriya"); list.Add("Soham"); list.Add("Sujan");
//            list.Add("Sagar"); list.Add("Shirisha"); list.Add("Arkabrata");
//            list.Add("Jitendra"); list.Add("Tejas"); list.Add("Trapti");
//            list.Add("Arkabrata"); list.Add("Rishita"); list.Add("Krishna");
//            list.Add("Abir"); list.Add("Debanjan"); list.Add("Debjani");
//            list.Add("Divyani"); list.Add("Amisha");
//            Console.WriteLine("Count:{0}", list.Count);
//            Console.WriteLine("Capacity:{0}", list.Capacity);
//            PrintValues("\nArray list Values:", list);
//            Console.WriteLine("Getting element's index position:" + list.IndexOf("Arkabrata"));
//            Console.WriteLine("Getting element's last index position:" + list.LastIndexOf("Arkabrata"));
//            list.Sort();
//            PrintValues("\n\nSorted Values:", list);

//            Console.WriteLine();
//        }
//        public static void PrintValues(string s, IEnumerable myList)
//        {
//            Console.WriteLine(s);
//            foreach (Object obj in myList)
//            {
//                Console.Write(obj + "\t");
//            }
//        }
//    }
//}









//Implement a railway ticket counter scenario where there are two queues- one general and one for senior citizen.
//Tickets are issued such that for every one person in senior citizen queue, two persons in general queue are processed.
//Write a program that takes input for 10 people who come at various points and print the list of people in the order of their processing sequence.
//Person : Name, age : Input
//Eg: Person1, Person4, Person5, Person6 -> SQ ; Remaining Person ->GQ
//Start Processing
//Process both queues completely
//Take care of all the elements in both the queues being dequed.
//If any queue is bigger, first take the approach, once one queue is emptied, dequeue the second queue without wait.







//using System;
//using System.Collections;
//using System.Collections.Generic;

//namespace Prj1Day19Col
//{
//    class Program
//    {
//        static void Main()
//        {
//            Queue GQ = new Queue();
//            Queue SQ = new Queue();

//            for (int i = 1; i <= 10; i++)
//            {
//                Console.Write($"Enter the name of Person {i}: ");
//                string name = Console.ReadLine();
//                Console.Write($"Enter the age of Person {i}: ");
//                int age = int.Parse(Console.ReadLine());

//                Person person = new Person(name, age);

//                if (age >= 60)
//                {
//                    SQ.Enqueue(person);
//                    Console.WriteLine($"{name} ,added to the Senior Citizen Queue.");
//                }
//                else
//                {
//                    GQ.Enqueue(person);
//                    Console.WriteLine($"{name} ,added to the General Citizen Queue.");
//                }
//            }

//            Console.WriteLine("\nProcessing Ticket Counter Queue...............");

//            while (SQ.Count > 0 || GQ.Count>0)
//            {
//                if(SQ.Count > 1)
//                {
//                    Console.WriteLine($"Processing Senior Citizen Ticket: {SQ.Dequeue()}");
//                }
//                else if (GQ.Count == 1)
//                {
//                    Console.WriteLine($"Processing General Citizen Ticket: {GQ.Dequeue()}");
//                    Console.WriteLine("No more people in the General Queue.");
//                }

//                if (GQ.Count >= 2)
//                {
//                    Console.WriteLine($"Processing General Citizen Ticket: {GQ.Dequeue()}");
//                    Console.WriteLine($"Processing General Citizen Ticket: {GQ.Dequeue()}");
//                }
//                else if (GQ.Count<2 || GQ.Count == 1)
//                {
//                    Console.WriteLine($"Processing General Citizen Ticket: {GQ.Dequeue()}");
//                    Console.WriteLine("No more people in the General Queue.");
//                }
//            }
//            while (SQ.Count > 0)
//            {

//                Console.WriteLine($"Processing Senior Citizen Ticket: {SQ.Dequeue()}");
//            }
//            while (GQ.Count > 0)
//            {

//                Console.WriteLine($"Processing General Citizen Ticket: {SQ.Dequeue()}");
//            }

//        }
//    }

//    class Person
//    {
//        public string Name { get; }
//        public int Age { get; }

//        public Person(string name, int age)
//        {
//            Name = name;
//            Age = age;
//        }

//        public override string ToString()
//        {
//            return $"{Name} (Age: {Age})";
//        }
//    }
//}

















//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Queue myQueue = new Queue();
//            myQueue.Enqueue("one");
//            Console.WriteLine("Total number of elements in the Queue are : " + myQueue.Count);
//            myQueue.Enqueue("two");
//            myQueue.Enqueue("three");
//            myQueue.Enqueue("four");
//            myQueue.Enqueue("five");
//            myQueue.Enqueue("six");
//            PrintValues("The Queue now is: ", myQueue);
//            Console.WriteLine("Total number of elements in the Queue are : " + myQueue.Count);
//            Console.WriteLine("Element at first is : " + myQueue.Peek());
//            Console.WriteLine("Element entered first that is removed from the Queue is : " + myQueue.Dequeue());
//            Console.WriteLine("Total number of elements in the Queue are : " + myQueue.Count);
//            PrintValues("The Queue after dequeue is: ", myQueue);
//            Object[] arr = myQueue.ToArray();
//            foreach (Object obj in arr)
//                Console.WriteLine(obj);
//        }
//        public static void PrintValues(string s, IEnumerable myList)
//        {
//            Console.WriteLine(s);
//            foreach (Object obj in myList)
//            {
//                Console.Write(obj + "\t");
//            }
//        }
//    }
//}











//Prepare 8 stack:
//CBS:
//{
//CBE: }
//SBS: [
//SBE: ]
//PS: (
//PE: )
//ABS: <
//ABE : >

//Push the elements from s accordingly.
//Check the length of each pair: Like:
//CBS.Length should be equal to CBE.Length

//If the length are unequal, output:
//	Compilation Error: Brackets mismatch
//Else if length pairs match:
//	Compiled successfully


//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program

//    {
//        public static String s = "String s = “using System;\r\nusing System.Collections;\r\nclass BitArrayExample {\r\n\tpublic static void Main()\t{\r\n\t\tBitArray myBitArr = new BitArray(5);\r\n\t\tmyBitArr[0] = true;\r\n\t\tmyBitArr[1] = true;\r\n\t\tmyBitArr[2] = false;\r\n\t\tmyBitArr[3] = true;\r\n\t\tmyBitArr[4] = false;\r\n\r\n\t\t// To get the value of index at index 2\r\n\t\tConsole.WriteLine(myBitArr.Get(2));\r\n\r\n\t\t// To get the value of index at index 3\r\n\t\tConsole.WriteLine(myBitArr.Get(3));\r\n\t}\r\n}";
//        static void Main(string[] args)
//        {
//            Stack  CBS= new Stack();
//            Stack CBE = new Stack();
//            Stack SBS = new Stack();
//            Stack SBE = new Stack();
//            Stack PS = new Stack();
//            Stack PE = new Stack();
//            Stack ABS = new Stack();
//            Stack ABE = new Stack();

//            for (int i=0; i<s.Length; i++) 
//            {

//                char ch = s[i];
//                string str=ch.ToString();
//                if (str == "{")
//                {
//                    CBS.Push(str);
//                }
//                else if (str == "}")
//                {
//                    CBE.Push(str);
//                }
//                else if(str == "[")
//                {
//                    SBS.Push(str);
//                }
//                else if (str == "]")
//                {
//                    SBE.Push(str);

//                }
//                else if (str == "(")
//                {
//                    PS.Push(str);
//                }
//                else if (str == ")")
//                {
//                    PE.Push(str);
//                }
//                else if (str == "<")
//                {
//                    ABS.Push(str);
//                }
//                else if( str == ">")
//                {
//                    ABE.Push(str);
//                }
//            }

//            int L = 0;
//            if(CBS.Count==CBE.Count) 
//            {
//                L += 1;
//            }
//            else { Console.WriteLine("Compilation Error: Brackets { and } mismatch"); }
//            if(SBS.Count==SBE.Count)
//            {
//                L += 1;
//            }
//            else { Console.WriteLine("Compilation Error: Brackets [ and ] mismatch"); }
//            if (PE.Count==PE.Count) { L += 1;}
//            else { Console.WriteLine("Compilation Error: Brackets ( and ) mismatch"); }
//            if (ABS.Count == ABE.Count) { L += 1; }
//            else { Console.WriteLine("Compilation Error: Brackets < and > mismatch"); }

//            if (L==4)
//            {
//                Console.WriteLine("Compiled successfully");
//            }
//            else { Console.WriteLine("Compilation Error: Brackets mismatch"); }



//        }
//    }
//}








//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Stack myStack = new Stack();
//            myStack.Push("1st Element");
//            myStack.Push("2nd Element");
//            myStack.Push("3rd Element");
//            myStack.Push("4th Element");
//            myStack.Push("5th Element");
//            myStack.Push("6th Element");
//            PrintValues("\nStack : ", myStack);
//            Console.Write("\nTotal number of elements in the Stack are : ");
//            Console.WriteLine(myStack.Count);
//            Console.WriteLine("Element at the top is : " + myStack.Peek());
//            Console.Write("\nTotal number of elements in the Stack are : ");
//            Console.WriteLine(myStack.Count);
//            Console.WriteLine("Element at the top that is removed from the Stack is : " + myStack.Pop());
//            Console.Write("Total number of elements in the Stack are : ");
//            Console.WriteLine(myStack.Count);
//            PrintValues("\nStack before clear all: ", myStack);
//            myStack.Clear();
//            PrintValues("\nStack post clear all: ", myStack);
//            Console.Write("Total number of elements in the Stack now are : ");
//            Console.WriteLine(myStack.Count);

//        }
//        public static void PrintValues(string s, IEnumerable myList)
//        {
//            Console.WriteLine(s);
//            foreach (Object obj in myList)
//            {
//                Console.Write(obj + "\t");
//            }
//        }
//    }
//}








//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            BitArray myActual = new BitArray(4);
//            BitArray myAns = new BitArray(4);
//            myActual[0] = true;
//            myActual[1] = false;
//            myActual[2] = true;
//            myActual[3] = true;

//            Console.WriteLine("Give the answer of below questions:(T or F)\n");
//            Console.WriteLine(" Q1: Collection namespace has ICollection: ");
//            string ans1 = Console.ReadLine();
//            if (ans1.ToLower() =="t") {
//                myAns[0] = true;
//            }


//            Console.WriteLine(" Q2: An IList in C# represents the class List in other language: ");
//            string ans2 = Console.ReadLine();
//            if (ans2.ToLower() == "t")
//            {
//                myAns[1] = true;
//            }


//            Console.WriteLine(" Q3: An Array and any collection is interchangeable object Types: ");
//            string ans3 = Console.ReadLine();
//            if (ans3.ToLower() == "t")
//            {
//                myAns[2] = true;
//            }


//            Console.WriteLine(" Q4: Collection is a part of BCL in .Net Framework: ");
//            string ans4 = Console.ReadLine();
//            if (ans4.ToLower() == "t")
//            {
//                myAns[3] = true;
//            }


//            int mark = 0;
//            for (int i = 0;i<4;i++)
//            {
//                if (myAns[i] == myActual[i])
//                {
//                    mark+=5;
//                }
//            }
//            Console.WriteLine("\nYour Marks is : " + mark);

//        }

//    }
//}















//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            bool[] b = new bool[] { true, false, true, true };
//            BitArray myBitArr = new BitArray(b);
//            // Checking if the BitArray is read-only
//            Console.WriteLine(myBitArr.IsReadOnly);
//            // To get the number of elements
//            // contained in the BitArray
//            Console.WriteLine(myBitArr.Count);
//            // To get the value of index at index 2
//            Console.WriteLine(myBitArr.Get(2));
//            PrintValues("\n\nThe BA Initially: ", myBitArr);
//            myBitArr.SetAll(false);
//            PrintValues("\n\nThe BA post setAll(false): ", myBitArr);
//            Console.WriteLine("\n\n");
//        }
//        public static void PrintValues(string s, IEnumerable myList)
//        {
//            Console.WriteLine(s);
//            foreach (Object obj in myList)
//            {
//                Console.Write(obj + "\t");
//            }
//        }
//    }
//}









//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            BitArray myBitArr1 = new BitArray(4);
//            BitArray myBitArr2 = new BitArray(4);
//            myBitArr1[0] = false;
//            myBitArr1[1] = false;
//            myBitArr1[2] = true;
//            myBitArr1[3] = true;
//            myBitArr2[0] = false;
//            myBitArr2[2] = false;
//            myBitArr2[1] = true;
//            myBitArr2[3] = true;
//            PrintValues("\n\nBA1 : ", myBitArr1);
//            PrintValues("\n\nBA2 : ", myBitArr2);
//            PrintValues("\n\nOr : BA1.Or(BA2) : ", myBitArr1.Or(myBitArr2));
//            Console.WriteLine("\n");
//        }
//        public static void PrintValues(string s, IEnumerable myList)
//        {
//            Console.WriteLine(s);
//            foreach (Object obj in myList)
//            {
//                Console.Write(obj + "\t");
//            }
//        }
//    }
//}







//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            bool[] b = new bool[] { true, false, true, false };
//            BitArray myBitArr = new BitArray(b);
//            // Checking if the BitArray is read-only
//            Console.WriteLine(myBitArr.IsReadOnly);
//            // To get the number of elements
//            // contained in the BitArray
//            Console.WriteLine(myBitArr.Count);
//            // To get the value of index at index 2
//            Console.WriteLine(myBitArr.Get(6));

//        }

//    }
//}



//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {

//            BitArray myBitArr = new BitArray(new byte[] { 0,0,0,1,1 });
//            // Checking if the BitArray is read-only
//            Console.WriteLine(myBitArr.IsReadOnly);
//            // To get the number of elements
//            // contained in the BitArray
//            Console.WriteLine(myBitArr.Count);
//            // To get the value of index at index 2
//            Console.WriteLine(myBitArr.Get(38));
//            foreach (var bit in myBitArr)
//            {
//                Console.Write(bit.ToString()+"\t");
//            }
//        }

//    }
//}








//using System;
//using System.Collections;

//namespace Prj1Day19Col
//{

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            BitArray myBitArr = new BitArray(5);
//            myBitArr[0] = true;
//            myBitArr[1] = true;
//            myBitArr[2] = false;
//            myBitArr[3] = true;
//            myBitArr[4] = false;

//            // To get the value of index at index 2
//            Console.WriteLine(myBitArr.Get(2));

//            // To get the value of index at index 3
//            Console.WriteLine(myBitArr.Get(3));

//        }

//    }
//}